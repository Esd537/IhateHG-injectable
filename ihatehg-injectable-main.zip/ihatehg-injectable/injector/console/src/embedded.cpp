#include "embedded.hpp"
#include <windows.h>
#include <bcrypt.h>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <vector>

std::filesystem::path embeddedLibrary() {
    HMODULE module = GetModuleHandleW(nullptr);
    HRSRC resource = FindResourceW(module, MAKEINTRESOURCEW(201), MAKEINTRESOURCEW(10));
    HGLOBAL loaded = resource ? LoadResource(module, resource) : nullptr;
    const auto* bytes = loaded ? static_cast<const unsigned char*>(LockResource(loaded)) : nullptr;
    DWORD size = resource ? SizeofResource(module, resource) : 0;
    if (!bytes || !size) throw std::runtime_error("Embedded DLL unavailable");

    unsigned char digest[32];
    if (BCryptHash(BCRYPT_SHA256_ALG_HANDLE, nullptr, 0, const_cast<PUCHAR>(bytes), size, digest, sizeof(digest)) < 0)
        throw std::runtime_error("Embedded DLL hash failed");
    std::wostringstream hash;
    for (unsigned char value : digest) hash << std::hex << std::setw(2) << std::setfill(L'0') << static_cast<unsigned>(value);

    wchar_t local[32768];
    DWORD length = GetEnvironmentVariableW(L"LOCALAPPDATA", local, 32768);
    if (!length || length >= 32768) throw std::runtime_error("Local application directory unavailable");
    auto directory = std::filesystem::path(local) / L"IHateHG" / hash.str();
    std::filesystem::create_directories(directory);
    auto path = directory / L"ihatehg_injector.dll";
    std::wstring lockName = L"Local\\IHateHG-" + hash.str();
    HANDLE lock = CreateMutexW(nullptr, FALSE, lockName.c_str());
    if (!lock) throw std::runtime_error("Payload lock unavailable");
    DWORD wait = WaitForSingleObject(lock, 30000);
    if (wait != WAIT_OBJECT_0 && wait != WAIT_ABANDONED) {
        CloseHandle(lock);
        throw std::runtime_error("Payload lock timed out");
    }
    try {
        bool matching = false;
        if (std::filesystem::is_regular_file(path) && std::filesystem::file_size(path) == size) {
            std::ifstream file(path, std::ios::binary);
            std::vector<unsigned char> existing(size);
            matching = static_cast<bool>(file.read(reinterpret_cast<char*>(existing.data()), size)) &&
                std::equal(existing.begin(), existing.end(), bytes);
        }
        if (!matching) {
            auto staging = directory / (L"payload-" + std::to_wstring(GetCurrentProcessId()) + L".tmp");
            std::ofstream file(staging, std::ios::binary | std::ios::trunc);
            file.write(reinterpret_cast<const char*>(bytes), size);
            file.close();
            if (!file || !MoveFileExW(staging.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
                std::filesystem::remove(staging);
                throw std::runtime_error("Embedded DLL extraction failed");
            }
        }
        ReleaseMutex(lock);
        CloseHandle(lock);
        return path;
    } catch (...) {
        ReleaseMutex(lock);
        CloseHandle(lock);
        throw;
    }
}
