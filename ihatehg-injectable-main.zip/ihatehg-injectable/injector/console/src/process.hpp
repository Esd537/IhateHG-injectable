#pragma once

#include <windows.h>
#include <filesystem>
#include <string>
#include <vector>

struct JavaProcess {
    DWORD pid;
    std::wstring name;
    std::wstring title;
};

std::vector<JavaProcess> javaProcesses();
DWORD selectProcess(const std::vector<JavaProcess>& processes);
void inject(DWORD pid, const std::filesystem::path& dll, bool rollback);
