#include "process.hpp"
#include <tlhelp32.h>
#include <algorithm>
#include <cwctype>
#include <iostream>
#include <stdexcept>

namespace {
class Handle {
public:
    explicit Handle(HANDLE value) : value_(value) {}
    ~Handle() { if (value_ && value_ != INVALID_HANDLE_VALUE) CloseHandle(value_); }
    Handle(const Handle&) = delete;
    Handle& operator=(const Handle&) = delete;
    HANDLE get() const { return value_; }
private:
    HANDLE value_;
};

void check(bool valid, const char* message) {
    if (!valid) throw std::runtime_error(std::string(message) + " (Win32=" + std::to_string(GetLastError()) + ")");
}

uintptr_t module(DWORD pid, const std::wstring& name, bool fullPath = false) {
    Handle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid));
    if (snapshot.get() == INVALID_HANDLE_VALUE) return 0;
    MODULEENTRY32W entry{};
    entry.dwSize = sizeof(entry);
    if (Module32FirstW(snapshot.get(), &entry)) do {
        if (!_wcsicmp(fullPath ? entry.szExePath : entry.szModule, name.c_str()))
            return reinterpret_cast<uintptr_t>(entry.modBaseAddr);
    } while (Module32NextW(snapshot.get(), &entry));
    return 0;
}

struct WindowSearch {
    DWORD pid;
    std::wstring title;
};

BOOL CALLBACK findWindow(HWND window, LPARAM parameter) {
    auto& search = *reinterpret_cast<WindowSearch*>(parameter);
    DWORD pid = 0;
    GetWindowThreadProcessId(window, &pid);
    if (pid != search.pid || !IsWindowVisible(window)) return TRUE;
    wchar_t title[512];
    if (GetWindowTextW(window, title, 512)) {
        search.title = title;
        return FALSE;
    }
    return TRUE;
}

bool gameWindow(const JavaProcess& process) {
    std::wstring title = process.title;
    std::transform(title.begin(), title.end(), title.begin(), [](wchar_t c) { return std::towlower(c); });
    return title.find(L"minecraft") != std::wstring::npos || title.find(L"lunar") != std::wstring::npos ||
            title.find(L"badlion") != std::wstring::npos;
}

DWORD run(HANDLE process, uintptr_t address, void* parameter, bool& finished) {
    Handle thread(CreateRemoteThread(process, nullptr, 0, reinterpret_cast<LPTHREAD_START_ROUTINE>(address), parameter, 0, nullptr));
    check(thread.get() != nullptr, "Could not start remote operation");
    finished = false;
    DWORD wait = WaitForSingleObject(thread.get(), 90000);
    finished = wait == WAIT_OBJECT_0;
    check(finished, "Remote operation timed out; it may still be running");
    DWORD status = 1;
    check(GetExitCodeThread(thread.get(), &status) != FALSE, "Remote result unavailable");
    return status;
}

uintptr_t loadLibraryAddress(DWORD pid) {
    FARPROC address = GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW");
    HMODULE owner = nullptr;
    check(address && GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            reinterpret_cast<LPCWSTR>(address), &owner), "LoadLibraryW unavailable");
    wchar_t path[32768];
    check(GetModuleFileNameW(owner, path, 32768) > 0, "Loader module unavailable");
    uintptr_t remote = module(pid, std::filesystem::path(path).filename().wstring());
    check(remote != 0, "Loader module missing from target");
    return remote + reinterpret_cast<uintptr_t>(address) - reinterpret_cast<uintptr_t>(owner);
}
}

std::vector<JavaProcess> javaProcesses() {
    Handle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0));
    check(snapshot.get() != INVALID_HANDLE_VALUE, "Could not enumerate processes");
    std::vector<JavaProcess> result;
    PROCESSENTRY32W entry{};
    entry.dwSize = sizeof(entry);
    if (Process32FirstW(snapshot.get(), &entry)) do {
        if (_wcsicmp(entry.szExeFile, L"java.exe") && _wcsicmp(entry.szExeFile, L"javaw.exe")) continue;
        if (!module(entry.th32ProcessID, L"jvm.dll")) continue;
        WindowSearch search{entry.th32ProcessID, {}};
        EnumWindows(findWindow, reinterpret_cast<LPARAM>(&search));
        result.push_back({entry.th32ProcessID, entry.szExeFile, search.title});
    } while (Process32NextW(snapshot.get(), &entry));
    std::sort(result.begin(), result.end(), [](const JavaProcess& a, const JavaProcess& b) { return a.pid < b.pid; });
    return result;
}

DWORD selectProcess(const std::vector<JavaProcess>& processes) {
    if (processes.empty()) throw std::runtime_error("No accessible java.exe/javaw.exe JVM found");
    std::vector<JavaProcess> candidates;
    for (const auto& process : processes) if (gameWindow(process)) candidates.push_back(process);
    if (candidates.empty()) candidates = processes;
    if (candidates.size() == 1) return candidates.front().pid;
    for (size_t i = 0; i < candidates.size(); ++i)
        std::wcout << L"[" << i + 1 << L"] " << candidates[i].pid << L" " << candidates[i].name << L" " << candidates[i].title << L'\n';
    std::wcout << L"Select: " << std::flush;
    std::wstring input;
    std::getline(std::wcin, input);
    if (input.empty() || input.find_first_not_of(L"0123456789") != std::wstring::npos) throw std::runtime_error("Invalid selection");
    unsigned long index = std::stoul(input);
    if (!index || index > candidates.size()) throw std::runtime_error("Invalid selection");
    return candidates[index - 1].pid;
}

void inject(DWORD pid, const std::filesystem::path& dll, bool rollback) {
    Handle process(OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION |
            PROCESS_VM_WRITE | PROCESS_VM_READ, FALSE, pid));
    check(process.get() != nullptr, "Could not open target process");
    USHORT architecture = 0, native = 0;
    check(IsWow64Process2(process.get(), &architecture, &native) != FALSE, "Target architecture unavailable");
    if (architecture != IMAGE_FILE_MACHINE_UNKNOWN || native != IMAGE_FILE_MACHINE_AMD64)
        throw std::runtime_error("An x64 JVM is required");
    if (!module(pid, L"jvm.dll")) throw std::runtime_error("Selected process has no JVM");
    uintptr_t remote = module(pid, dll.wstring(), true);
    if (!remote) {
        if (rollback) throw std::runtime_error("DLL is not loaded in this process");
        uintptr_t loader = loadLibraryAddress(pid);
        std::wstring path = dll.wstring();
        size_t size = (path.size() + 1) * sizeof(wchar_t);
        void* buffer = VirtualAllocEx(process.get(), nullptr, size, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
        check(buffer != nullptr, "Could not allocate DLL path");
        bool finished = true;
        try {
            SIZE_T written = 0;
            check(WriteProcessMemory(process.get(), buffer, path.c_str(), size, &written) && written == size, "Could not copy DLL path");
            run(process.get(), loader, buffer, finished);
        } catch (...) {
            if (finished) VirtualFreeEx(process.get(), buffer, 0, MEM_RELEASE);
            throw;
        }
        VirtualFreeEx(process.get(), buffer, 0, MEM_RELEASE);
        remote = module(pid, path, true);
        check(remote != 0, "LoadLibraryW failed to load the DLL");
    }
    HMODULE image = LoadLibraryExW(dll.c_str(), nullptr, DONT_RESOLVE_DLL_REFERENCES);
    check(image != nullptr, "Could not read DLL exports");
    FARPROC operation = GetProcAddress(image, rollback ? "Rollback" : "Initialize");
    if (!operation) { FreeLibrary(image); throw std::runtime_error("DLL export missing; use the matching DLL"); }
    uintptr_t address = remote + reinterpret_cast<uintptr_t>(operation) - reinterpret_cast<uintptr_t>(image);
    FreeLibrary(image);
    bool finished = true;
    if (run(process.get(), address, nullptr, finished))
        throw std::runtime_error("JVM bootstrap failed. Check ihatehg-native.log beside the DLL");
}
