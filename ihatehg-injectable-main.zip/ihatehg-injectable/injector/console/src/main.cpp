#include "process.hpp"
#include "embedded.hpp"
#include <iostream>
#include <stdexcept>

namespace fs = std::filesystem;

int wmain(int argc, wchar_t** argv) {
    SetConsoleTitleW(L"made by rogerio, forked by angel");
    std::wcout << L"https://discord.gg/ANfdGTW99B\n" << std::flush;
    try {
        DWORD pid = 0;
        bool rollback = false, list = false;
        fs::path dll;
        for (int i = 1; i < argc; ++i) {
            std::wstring argument = argv[i];
            if (argument == L"--rollback") rollback = true;
            else if (argument == L"--list") list = true;
            else if (!pid) {
                if (argument.empty() || argument.find_first_not_of(L"0123456789") != std::wstring::npos)
                    throw std::runtime_error("Invalid PID");
                unsigned long value = std::stoul(argument);
                if (!value) throw std::runtime_error("Invalid PID");
                pid = value;
            } else dll = argument;
        }
        if (list) {
            for (const auto& process : javaProcesses())
                std::wcout << process.pid << L" " << process.name << L" " << process.title << L'\n';
            return 0;
        }
        if (!pid) pid = selectProcess(javaProcesses());
        if (dll.empty()) dll = embeddedLibrary();
        dll = fs::weakly_canonical(fs::absolute(dll));
        if (!fs::is_regular_file(dll)) throw std::runtime_error("DLL unavailable");
        std::wcout << (rollback ? L"[+] Restoring classes...\n" : L"[+] Transforming classes...\n") << std::flush;
        inject(pid, dll, rollback);
        if (rollback) std::wcout << L"[+] Restored\n";
        else std::wcout << L"[+] Hooked\n[+] Done, sucessfully injected\n";
        std::wcout << L"[/] Closing in 3s...\n" << std::flush;
        Sleep(3000);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "[-] " << error.what() << '\n';
        return 1;
    }
}
