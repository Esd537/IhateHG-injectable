import com.sun.tools.attach.VirtualMachine;
import java.nio.file.Paths;

public final class Attach {
    public static void main(String[] args) throws Exception {
        if (args.length < 2 || args.length > 3) {
            throw new IllegalArgumentException("Attach <pid> <absolute dll path> [rollback]");
        }
        VirtualMachine vm = VirtualMachine.attach(args[0]);
        try { vm.loadAgentPath(Paths.get(args[1]).toAbsolutePath().toString(), args.length == 3 ? args[2] : ""); }
        finally { vm.detach(); }
    }
}
