#include <windows.h>
#include <jni.h>
#include <jvmti.h>
#include <atomic>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <mutex>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>

namespace {
HMODULE selfModule = nullptr;

void log(const char* format, ...) {
    char message[2048];
    va_list args;
    va_start(args, format);
    vsnprintf(message, sizeof(message), format, args);
    va_end(args);
    std::fputs(message, stderr);
    OutputDebugStringA(message);
    wchar_t path[MAX_PATH];
    if (selfModule && GetModuleFileNameW(selfModule, path, MAX_PATH)) {
        wchar_t* slash = wcsrchr(path, L'\\');
        if (slash) {
            wcscpy_s(slash + 1, MAX_PATH - (slash + 1 - path), L"ihatehg-native.log");
            FILE* file = nullptr;
            if (_wfopen_s(&file, path, L"ab") == 0 && file) { std::fputs(message, file); std::fclose(file); }
        }
    }
}
jvmtiEnv* ti = nullptr;
jclass bootstrap = nullptr;
jobject gameLoader = nullptr;
jmethodID transformMethod = nullptr;
std::unordered_set<std::string> targets;
std::mutex targetMutex;
std::mutex attachMutex;
std::atomic<bool> callbackFailed{false};
bool setupComplete = false;
thread_local bool insideHook = false;
const char* bootstrapName = "me.viniciusroger.ihatehg.transform.NativeBootstrap";

void check(jvmtiError error, const char* operation) {
    if (error != JVMTI_ERROR_NONE) throw std::runtime_error(std::string(operation) + " JVMTI error=" + std::to_string(error));
}
void javaCheck(JNIEnv* env, const char* operation) {
    if (env->ExceptionCheck()) {
        env->ExceptionDescribe();
        env->ExceptionClear();
        throw std::runtime_error(std::string(operation) + " failed (Java exception above)");
    }
}
std::string signatureName(jclass klass) {
    char* signature = nullptr;
    check(ti->GetClassSignature(klass, &signature, nullptr), "GetClassSignature");
    std::string result(signature);
    ti->Deallocate(reinterpret_cast<unsigned char*>(signature));
    if (result.size() > 2 && result.front() == 'L') result = result.substr(1, result.size() - 2);
    for (char& c : result) if (c == '/') c = '.';
    return result;
}
struct LoadedClasses {
    JNIEnv* env;
    jint count = 0;
    jclass* classes = nullptr;
    explicit LoadedClasses(JNIEnv* e) : env(e) { check(ti->GetLoadedClasses(&count, &classes), "GetLoadedClasses"); }
    ~LoadedClasses() {
        for (jint i = 0; i < count; ++i) env->DeleteLocalRef(classes[i]);
        if (classes) ti->Deallocate(reinterpret_cast<unsigned char*>(classes));
    }
};

void JNICALL classHook(jvmtiEnv*, JNIEnv* env, jclass redefining, jobject loader,
        const char* name, jobject, jint length, const unsigned char* bytes,
        jint* newLength, unsigned char** newBytes) {
    if (insideHook || !bootstrap || !env->IsSameObject(loader, gameLoader)) return;

    if (env->ExceptionCheck()) return;
    try {
        std::string dotted = name ? name : (redefining ? signatureName(redefining) : "");
        for (char& c : dotted) if (c == '/') c = '.';
        {
            std::lock_guard<std::mutex> lock(targetMutex);
            if (!targets.count(dotted)) return;
        }
        insideHook = true;
        struct Reset { ~Reset() { insideHook = false; } } reset;
        if (env->PushLocalFrame(8) != JNI_OK) throw std::runtime_error("PushLocalFrame");
        struct Frame { JNIEnv* env; ~Frame() { env->PopLocalFrame(nullptr); } } frame{env};
        jstring className = env->NewStringUTF(dotted.c_str());
        jbyteArray input = env->NewByteArray(length);
        javaCheck(env, "Allocate hook input");
        env->SetByteArrayRegion(input, 0, length, reinterpret_cast<const jbyte*>(bytes));
        javaCheck(env, "Copy hook input");
        auto output = static_cast<jbyteArray>(env->CallStaticObjectMethod(bootstrap, transformMethod, className, input));
        javaCheck(env, "Transform bytecode");
        if (!output) return;
        jint size = env->GetArrayLength(output);
        if (size <= 0) throw std::runtime_error("Empty transformed bytecode");
        unsigned char* allocated = nullptr;
        check(ti->Allocate(size, &allocated), "Allocate transformed bytecode");
        env->GetByteArrayRegion(output, 0, size, reinterpret_cast<jbyte*>(allocated));
        if (env->ExceptionCheck()) {
            ti->Deallocate(allocated);
            javaCheck(env, "Copy hook output");
        }
        *newLength = size;
        *newBytes = allocated; 
    } catch (const std::exception& error) {
        callbackFailed = true;
        log("[ihatehg] ClassFileLoadHook: %s\n", error.what());
        if (env->ExceptionCheck()) { env->ExceptionDescribe(); env->ExceptionClear(); }
    }
}

void JNICALL retransform(JNIEnv* env, jclass, jobjectArray names, jobject loader) {
    try {
        if (!env->IsSameObject(loader, gameLoader)) throw std::runtime_error("Unexpected target class loader");
        std::unordered_set<std::string> requested;
        for (jsize i = 0; i < env->GetArrayLength(names); ++i) {
            auto name = static_cast<jstring>(env->GetObjectArrayElement(names, i));
            const char* chars = env->GetStringUTFChars(name, nullptr);
            javaCheck(env, "Read target name");
            requested.emplace(chars);
            env->ReleaseStringUTFChars(name, chars);
            env->DeleteLocalRef(name);
        }
        { std::lock_guard<std::mutex> lock(targetMutex); targets = requested; }
        LoadedClasses loaded(env);
        std::vector<jclass> selected;
        for (jint i = 0; i < loaded.count; ++i) {
            if (!requested.count(signatureName(loaded.classes[i]))) continue;
            jobject definingLoader = nullptr;
            check(ti->GetClassLoader(loaded.classes[i], &definingLoader), "GetClassLoader");
            bool same = env->IsSameObject(definingLoader, loader);
            env->DeleteLocalRef(definingLoader);
            if (!same) continue;
            jboolean modifiable = JNI_FALSE;
            check(ti->IsModifiableClass(loaded.classes[i], &modifiable), "IsModifiableClass");
            if (!modifiable) throw std::runtime_error("Target is not modifiable");
            selected.push_back(loaded.classes[i]);
        }
        callbackFailed = false;
        if (!selected.empty()) check(ti->RetransformClasses(static_cast<jint>(selected.size()), selected.data()), "RetransformClasses");
        if (callbackFailed.load()) throw std::runtime_error("Transformer failed; manager must roll back");
        log("[ihatehg] RetransformClasses OK: %zu loaded target(s); %zu registered\n", selected.size(), requested.size());
    } catch (const std::exception& error) {
        if (!env->ExceptionCheck()) env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), error.what());
    }
}

std::wstring extractJar(int resourceId) {
    HMODULE module = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            reinterpret_cast<LPCWSTR>(&extractJar), &module)) throw std::runtime_error("GetModuleHandleExW");
    HRSRC resource = FindResourceW(module, MAKEINTRESOURCEW(resourceId), MAKEINTRESOURCEW(10));
    if (!resource) throw std::runtime_error("Embedded JAR resource missing");
    DWORD size = SizeofResource(module, resource);
    const void* data = LockResource(LoadResource(module, resource));
    if (!size || !data) throw std::runtime_error("Embedded JAR is empty");
    wchar_t temp[MAX_PATH], path[MAX_PATH];
    DWORD tempSize = GetTempPathW(MAX_PATH, temp);
    if (!tempSize || tempSize >= MAX_PATH || !GetTempFileNameW(temp, L"ihg", 0, path)) throw std::runtime_error("Temporary JAR path");
    HANDLE file = CreateFileW(path, GENERIC_WRITE, 0, nullptr, TRUNCATE_EXISTING, FILE_ATTRIBUTE_TEMPORARY, nullptr);
    if (file == INVALID_HANDLE_VALUE) { DeleteFileW(path); throw std::runtime_error("Create embedded JAR"); }
    DWORD written = 0;
    bool ok = WriteFile(file, data, size, &written, nullptr) && written == size;
    CloseHandle(file);
    if (!ok) { DeleteFileW(path); throw std::runtime_error("Write embedded JAR"); }
    log("[ihatehg] embedded JAR: %ls (%lu bytes)\n", path, size);
    return path;
}

jclass loadClass(JNIEnv* env, jobject loader, const char* name) {
    jclass loaderClass = env->GetObjectClass(loader);
    jmethodID load = env->GetMethodID(loaderClass, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    javaCheck(env, "ClassLoader.loadClass lookup");
    jstring className = env->NewStringUTF(name);
    auto result = static_cast<jclass>(env->CallObjectMethod(loader, load, className));
    env->DeleteLocalRef(className);
    env->DeleteLocalRef(loaderClass);
    javaCheck(env, name);
    return result;
}

jobject findGameLoader(JNIEnv* env) {
    LoadedClasses loaded(env);
    jobject loader = nullptr;
    for (jint i = 0; i < loaded.count; ++i) {
        if (signatureName(loaded.classes[i]) != "net.minecraft.client.Minecraft") continue;
        if (loader) throw std::runtime_error("Multiple Minecraft class loaders");
        check(ti->GetClassLoader(loaded.classes[i], &loader), "Find Minecraft loader");
    }
    if (loader) return loader;
    jint count = 0;
    jthread* threads = nullptr;
    check(ti->GetAllThreads(&count, &threads), "GetAllThreads");
    for (jint i = 0; i < count; ++i) {
        jvmtiThreadInfo info{};
        if (ti->GetThreadInfo(threads[i], &info) == JVMTI_ERROR_NONE) {
            bool client = info.name && (!std::strcmp(info.name, "Client thread") || !std::strcmp(info.name, "Render thread"));
            if (!loader && client && info.context_class_loader) loader = env->NewLocalRef(info.context_class_loader);
            if (info.name) ti->Deallocate(reinterpret_cast<unsigned char*>(info.name));
            env->DeleteLocalRef(info.thread_group);
            env->DeleteLocalRef(info.context_class_loader);
        }
        env->DeleteLocalRef(threads[i]);
    }
    ti->Deallocate(reinterpret_cast<unsigned char*>(threads));
    if (loader) {
        jclass minecraft = loadClass(env, loader, "net.minecraft.client.Minecraft");
        jobject defining = nullptr;
        check(ti->GetClassLoader(minecraft, &defining), "Resolve defining game loader");
        env->DeleteLocalRef(minecraft);
        env->DeleteLocalRef(loader);
        loader = defining;
    }
    return loader;
}

void definePayload(JNIEnv* env, jobject loader, jobject file) {
    jclass jarType = env->FindClass("java/util/jar/JarFile");
    jobject jar = env->NewObject(jarType, env->GetMethodID(jarType, "<init>", "(Ljava/io/File;)V"), file);
    javaCheck(env, "Open payload JAR");
    jobject entries = env->CallObjectMethod(jar, env->GetMethodID(jarType, "entries", "()Ljava/util/Enumeration;"));
    jclass enumeration = env->FindClass("java/util/Enumeration");
    jmethodID hasNext = env->GetMethodID(enumeration, "hasMoreElements", "()Z");
    jmethodID next = env->GetMethodID(enumeration, "nextElement", "()Ljava/lang/Object;");
    jclass zipEntry = env->FindClass("java/util/zip/ZipEntry");
    jmethodID getName = env->GetMethodID(zipEntry, "getName", "()Ljava/lang/String;");
    jmethodID getStream = env->GetMethodID(jarType, "getInputStream", "(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;");
    jclass inputType = env->FindClass("java/io/InputStream");
    jmethodID read = env->GetMethodID(inputType, "read", "([B)I");
    jmethodID close = env->GetMethodID(inputType, "close", "()V");
    jbyteArray buffer = env->NewByteArray(8192);
    struct Entry { std::string name; std::vector<jbyte> bytes; bool done = false; };
    std::vector<Entry> classes;
    try {
        while (env->CallBooleanMethod(entries, hasNext)) {
            jobject entry = env->CallObjectMethod(entries, next);
            auto nameObject = static_cast<jstring>(env->CallObjectMethod(entry, getName));
            const char* chars = env->GetStringUTFChars(nameObject, nullptr);
            javaCheck(env, "Read JAR class entry");
            std::string name(chars);
            env->ReleaseStringUTFChars(nameObject, chars);
            env->DeleteLocalRef(nameObject);
            if (name.size() > 6 && name.compare(name.size() - 6, 6, ".class") == 0 &&
                    (name.rfind("me/viniciusroger/ihatehg/", 0) == 0 || name.rfind("io/github/nevalackin/homoBus/", 0) == 0 ||
                     name.rfind("net/superblaubeere27/", 0) == 0)) {
                Entry item{name.substr(0, name.size() - 6), {}};
                jobject input = env->CallObjectMethod(jar, getStream, entry);
                javaCheck(env, "Read JAR class stream");
                jint size;
                while ((size = env->CallIntMethod(input, read, buffer)) > 0) {
                    size_t offset = item.bytes.size();
                    item.bytes.resize(offset + size);
                    env->GetByteArrayRegion(buffer, 0, size, item.bytes.data() + offset);
                    javaCheck(env, "Copy JAR class");
                }
                javaCheck(env, "Read class bytes");
                env->CallVoidMethod(input, close);
                env->DeleteLocalRef(input);
                classes.push_back(std::move(item));
            }
            env->DeleteLocalRef(entry);
            javaCheck(env, "Enumerate payload");
        }
        env->CallVoidMethod(jar, env->GetMethodID(jarType, "close", "()V"));
        javaCheck(env, "Close payload JAR");
    } catch (...) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->CallVoidMethod(jar, env->GetMethodID(jarType, "close", "()V"));
        throw;
    }
    jclass missingType = env->FindClass("java/lang/NoClassDefFoundError");
    jclass duplicateType = env->FindClass("java/lang/LinkageError");
    size_t remaining = classes.size();
    while (remaining) {
        size_t progress = 0;
        for (auto& item : classes) {
            if (item.done) continue;
            jclass defined = env->DefineClass(item.name.c_str(), loader, item.bytes.data(), static_cast<jsize>(item.bytes.size()));
            if (defined && !env->ExceptionCheck()) {
                env->DeleteLocalRef(defined);
                item.done = true; --remaining; ++progress;
                continue;
            }
            jthrowable problem = env->ExceptionOccurred();
            env->ExceptionClear();
            bool missing = problem && env->IsInstanceOf(problem, missingType);

            if (!missing && problem && env->IsInstanceOf(problem, duplicateType)) {
                std::string dotted = item.name;
                for (char& c : dotted) if (c == '/') c = '.';
                try {
                    jclass existing = loadClass(env, loader, dotted.c_str());
                    jobject defining = nullptr;
                    check(ti->GetClassLoader(existing, &defining), "Check defined payload identity");
                    bool same = env->IsSameObject(defining, loader);
                    env->DeleteLocalRef(defining); env->DeleteLocalRef(existing);
                    if (same) { item.done = true; --remaining; ++progress; }
                } catch (...) {}
            }
            if (!missing && !item.done) {
                env->Throw(problem); env->DeleteLocalRef(problem);
                javaCheck(env, item.name.c_str());
            }
            env->DeleteLocalRef(problem);
        }
        if (!progress) throw std::runtime_error("DefineClass could not resolve payload dependencies (" + std::to_string(remaining) + " remaining)");
    }
    log("[ihatehg] DefineClass: %zu payload classes in actual game loader\n", classes.size());
}

void install(JNIEnv* env) {
    LoadedClasses loaded(env);
    jobject loader = findGameLoader(env);
    for (jint i = 0; i < loaded.count; ++i) {
        std::string name = signatureName(loaded.classes[i]);
        if (name == "me.viniciusroger.ihatehg.IHateHG" || name == bootstrapName)
            throw std::runtime_error("IHateHG already loaded; do not combine mod and native payload");
    }
    if (!loader) throw std::runtime_error("Start Forge 1.8.9 before attaching this agent");
    jclass loaderClass = env->GetObjectClass(loader);
    jmethodID addURL = env->GetMethodID(loaderClass, "addURL", "(Ljava/net/URL;)V");
    if (!addURL && env->ExceptionCheck()) env->ExceptionClear();
    jclass minecraft = loadClass(env, loader, "net.minecraft.client.Minecraft");
    const char* descriptor = "()Lnet/minecraft/client/Minecraft;";
    jmethodID getter = env->GetStaticMethodID(minecraft, "getMinecraft", descriptor);
    bool mcp = getter != nullptr;
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (!mcp) {
        getter = env->GetStaticMethodID(minecraft, "func_71410_x", descriptor);
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (!getter) throw std::runtime_error("Unknown Minecraft 1.8.9 member namespace");
    }
    env->DeleteLocalRef(minecraft);
    log("[ihatehg] runtime mappings: %s; payload resource=%d\n", mcp ? "MCP (Lunar/vanilla named)" : "SRG (Forge)", mcp ? 102 : 101);
    std::wstring path = extractJar(mcp ? 102 : 101);
    jclass fileClass = env->FindClass("java/io/File");
    jmethodID constructor = env->GetMethodID(fileClass, "<init>", "(Ljava/lang/String;)V");
    jstring javaPath = env->NewString(reinterpret_cast<const jchar*>(path.data()), static_cast<jsize>(path.size()));
    jobject file = env->NewObject(fileClass, constructor, javaPath);
    env->CallVoidMethod(file, env->GetMethodID(fileClass, "deleteOnExit", "()V"));
    jobject uri = env->CallObjectMethod(file, env->GetMethodID(fileClass, "toURI", "()Ljava/net/URI;"));
    jclass uriClass = env->FindClass("java/net/URI");
    jobject url = env->CallObjectMethod(uri, env->GetMethodID(uriClass, "toURL", "()Ljava/net/URL;"));
    javaCheck(env, "Embedded JAR URL");
    if (addURL) {
        env->CallVoidMethod(loader, addURL, url);
        javaCheck(env, "Add JAR to Minecraft loader");
        log("[ihatehg] payload: addURL into actual game loader\n");
    } else definePayload(env, loader, file);

    jmethodID exclude = env->GetMethodID(loaderClass, "addTransformerExclusion", "(Ljava/lang/String;)V");
    if (exclude) {
        jstring package = env->NewStringUTF("me.viniciusroger.ihatehg.transform.");
        env->CallVoidMethod(loader, exclude, package);
        jstring internal = env->NewStringUTF("me.viniciusroger.ihatehg.internal.");
        env->CallVoidMethod(loader, exclude, internal);
        javaCheck(env, "Exclude transformation infrastructure");
    } else if (env->ExceptionCheck()) env->ExceptionClear();
    jclass bridge = loadClass(env, loader, "me.viniciusroger.ihatehg.transform.NativeBridge");
    HMODULE pinned = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN,
            reinterpret_cast<LPCWSTR>(&install), &pinned)) throw std::runtime_error("Pin registered native module");
    JNINativeMethod methods[] = {{const_cast<char*>("retransform"), const_cast<char*>("([Ljava/lang/String;Ljava/lang/ClassLoader;)V"), reinterpret_cast<void*>(&retransform)}};
    if (env->RegisterNatives(bridge, methods, 1) != JNI_OK) throw std::runtime_error("RegisterNatives");
    jclass entry = loadClass(env, loader, bootstrapName);
    bootstrap = static_cast<jclass>(env->NewGlobalRef(entry));
    gameLoader = env->NewGlobalRef(loader);
    transformMethod = env->GetStaticMethodID(bootstrap, "transform", "(Ljava/lang/String;[B)[B");
    javaCheck(env, "NativeBootstrap.transform lookup");
    jmethodID configure = env->GetStaticMethodID(bootstrap, "configure", "(Ljava/lang/String;)V");
    javaCheck(env, "Payload configure method");
    env->CallStaticVoidMethod(bootstrap, configure, javaPath);
    javaCheck(env, "Configure payload resources");

    for (const char* name : {"net.minecraft.client.entity.EntityPlayerSP", "net.minecraft.client.renderer.EntityRenderer"}) {
        jclass target = loadClass(env, loader, name);
        env->DeleteLocalRef(target);
    }
    jvmtiEventCallbacks callbacks{};
    callbacks.ClassFileLoadHook = classHook;
    check(ti->SetEventCallbacks(&callbacks, sizeof(callbacks)), "SetEventCallbacks");
    check(ti->SetEventNotificationMode(JVMTI_ENABLE, JVMTI_EVENT_CLASS_FILE_LOAD_HOOK, nullptr), "Enable ClassFileLoadHook");
    setupComplete = true;
}
} 

extern "C" JNIEXPORT jint JNICALL Agent_OnAttach(JavaVM* vm, char* options, void*) {

    std::lock_guard<std::mutex> lock(attachMutex);
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_8) != JNI_OK) return JNI_ERR;
    if (env->PushLocalFrame(64) != JNI_OK) return JNI_ERR;
    struct Frame { JNIEnv* env; ~Frame() { env->PopLocalFrame(nullptr); } } frame{env};
    try {
        bool rollback = options && std::strcmp(options, "rollback") == 0;
        if (options && *options && !rollback) throw std::runtime_error("Unknown option; use empty options or rollback");
        if (!ti) {
            if (rollback) throw std::runtime_error("Agent is not installed");
            if (vm->GetEnv(reinterpret_cast<void**>(&ti), JVMTI_VERSION_1_2) != JNI_OK) throw std::runtime_error("JVMTI 1.2 unavailable");
            jvmtiCapabilities capabilities{};
            capabilities.can_retransform_classes = 1;
            check(ti->AddCapabilities(&capabilities), "Add can_retransform_classes");
        }
        if (!bootstrap) install(env);
        if (!setupComplete) throw std::runtime_error("Previous bootstrap incomplete; restart this test JVM before retrying");
        jmethodID operation = env->GetStaticMethodID(bootstrap, rollback ? "stop" : "start", "()V");
        javaCheck(env, "Bootstrap operation lookup");
        env->CallStaticVoidMethod(bootstrap, operation);
        javaCheck(env, rollback ? "Rollback" : "TransformManager.init");
        log("[ihatehg] %s OK\n", rollback ? "rollback" : "init");

        return JNI_OK;
    } catch (const std::exception& error) {
        log("[ihatehg] attach failed: %s\n", error.what());

        if (env->ExceptionCheck()) { env->ExceptionDescribe(); env->ExceptionClear(); }
        return JNI_ERR;
    }
}

namespace {
DWORD execute(const char* option) {
    HMODULE jvm = GetModuleHandleW(L"jvm.dll");
    using GetVMs = jint (JNICALL*)(JavaVM**, jsize, jsize*);
    auto getVMs = jvm ? reinterpret_cast<GetVMs>(GetProcAddress(jvm, "JNI_GetCreatedJavaVMs")) : nullptr;
    JavaVM* vm = nullptr;
    jsize count = 0;
    if (!getVMs || getVMs(&vm, 1, &count) != JNI_OK || count != 1 || !vm) {
        log("[ihatehg] JVM discovery failed\n");
        return 1;
    }
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThreadAsDaemon(reinterpret_cast<void**>(&env), nullptr) != JNI_OK) {
        log("[ihatehg] AttachCurrentThreadAsDaemon failed\n");
        return 1;
    }
    jint status = Agent_OnAttach(vm, const_cast<char*>(option), nullptr);
    vm->DetachCurrentThread();
    return status == JNI_OK ? 0 : 1;
}
}

extern "C" __declspec(dllexport) DWORD WINAPI Initialize(void*) { return execute(""); }
extern "C" __declspec(dllexport) DWORD WINAPI Rollback(void*) { return execute("rollback"); }

BOOL WINAPI DllMain(HINSTANCE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) selfModule = module;
    return TRUE;
}
