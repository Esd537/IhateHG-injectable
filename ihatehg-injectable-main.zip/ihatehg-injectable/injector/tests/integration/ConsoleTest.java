import java.io.*;

public final class ConsoleTest {
    private static String output(Process process) throws Exception {
        StringBuilder result = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        for (String line; (line = reader.readLine()) != null;) result.append(line).append('\n');
        if (process.waitFor() != 0) throw new AssertionError(result.toString());
        return result.toString();
    }

    private static void check(BufferedWriter input, BufferedReader reader, String state) throws Exception {
        input.write(state); input.newLine(); input.flush();
        String line = reader.readLine();
        if (line == null || !line.startsWith("PASS " + state)) throw new AssertionError(String.valueOf(line));
        System.out.println(line);
    }

    public static void main(String[] args) throws Exception {
        String java = args[0], host = args[1], fixture = args[2], injector = args[3];
        Process game = new ProcessBuilder(java, "-Xverify:all", "-cp", host, "FixtureHost", fixture, "url").start();
        BufferedReader reader = new BufferedReader(new InputStreamReader(game.getInputStream()));
        BufferedWriter input = new BufferedWriter(new OutputStreamWriter(game.getOutputStream()));
        try {
            String ready = reader.readLine();
            if (ready == null || !ready.startsWith("READY ")) throw new AssertionError("Fixture unavailable");
            String pid = ready.substring(6);
            String detected = output(new ProcessBuilder(injector, "--list").redirectErrorStream(true).start());
            if (!detected.contains(pid + " java.exe")) throw new AssertionError("Java process not detected: " + detected);
            System.out.println("PASS detection: fixture java.exe found");
            check(input, reader, "baseline");
            for (int round = 0; round < 2; round++) {
                String text = output(new ProcessBuilder(injector, pid).redirectErrorStream(true).start());
                String expected = "https://discord.gg/ANfdGTW99B\n[+] Transforming classes...\n[+] Hooked\n[+] Done, sucessfully injected\n[/] Closing in 3s...\n";
                if (!text.equals(expected)) throw new AssertionError(text);
                System.out.print(text);
                check(input, reader, "modified");
                check(input, reader, "constructor");
                System.out.print(output(new ProcessBuilder(injector, pid, "--rollback").redirectErrorStream(true).start()));
                check(input, reader, "rollback");
            }
            input.write("exit"); input.newLine(); input.flush();
            if (game.waitFor() != 0) throw new AssertionError("Fixture failed");
            System.out.println("PASS console: exact output, LoadLibraryW, transformations, rollback, reactivation");
        } finally { game.destroy(); }
    }
}
