import java.io.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;

public final class PayloadMappingTest {
    public static void main(String[] args) throws Exception {
        check(args[0], "getMinecraft");
        check(args[1], "func_71410_x");
        System.out.println("PASS payload namespaces: crash-site getter is MCP/SRG as expected");
    }

    private static void check(String path, String getter) throws Exception {
        final boolean[] found = {false};
        try (JarFile jar = new JarFile(path)) {
            if (jar.getJarEntry("mappings/1.8.9/methods.csv") == null || jar.getJarEntry("mappings/1.8.9/fields.csv") == null)
                throw new AssertionError("Mappings absent");
            try (InputStream input = jar.getInputStream(jar.getJarEntry("me/viniciusroger/ihatehg/command/Command.class"))) {
                new ClassReader(input).accept(new ClassVisitor(Opcodes.ASM9) {
                    @Override public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
                        return new MethodVisitor(Opcodes.ASM9) {
                            @Override public void visitMethodInsn(int opcode, String owner, String method, String descriptor, boolean itf) {
                                if (owner.equals("net/minecraft/client/Minecraft") && descriptor.equals("()Lnet/minecraft/client/Minecraft;")) {
                                    if (!method.equals(getter)) throw new AssertionError(path + " uses " + method);
                                    found[0] = true;
                                }
                            }
                        };
                    }
                }, 0);
            }
        }
        if (!found[0]) throw new AssertionError("Crash-site getter not found");
    }
}
