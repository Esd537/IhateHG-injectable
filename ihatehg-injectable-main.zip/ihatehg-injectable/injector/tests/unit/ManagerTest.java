import me.viniciusroger.ihatehg.transform.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

public final class ManagerTest {
    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    private static byte[] fixture(String name, int kind, boolean srg) {
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        writer.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC, name.replace('.', '/'), null, "java/lang/Object", null);
        method(writer, "<init>", "()V", true, false, name);
        if (kind == 0) {
            method(writer, srg ? "func_71407_l" : "runTick", "()V", false, true, name);
            method(writer, srg ? "func_152348_aa" : "dispatchKeypresses", "()V", false, false, name);
        } else if (kind == 1) {
            method(writer, srg ? "func_70071_h_" : "onUpdate", "()V", false, false, name);
            method(writer, srg ? "func_71165_d" : "sendChatMessage", "(Ljava/lang/String;)V", false, false, name);
        } else method(writer, srg ? "func_181560_a" : "updateCameraAndRender", "(FJ)V", false, false, name);
        writer.visitEnd();
        return writer.toByteArray();
    }
    private static void method(ClassWriter writer, String name, String desc, boolean constructor, boolean tick, String owner) {
        MethodVisitor visitor = writer.visitMethod(Opcodes.ACC_PUBLIC, name, desc, null, null);
        visitor.visitCode();
        if (constructor) {
            visitor.visitVarInsn(Opcodes.ALOAD, 0);
            visitor.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        }
        if (tick) {
            visitor.visitVarInsn(Opcodes.ALOAD, 0);
            visitor.visitMethodInsn(Opcodes.INVOKEVIRTUAL, owner.replace('.', '/'),
                    name.equals("runTick") ? "dispatchKeypresses" : "func_152348_aa", "()V", false);
        }
        visitor.visitInsn(Opcodes.RETURN);
        visitor.visitMaxs(0, 0);
        visitor.visitEnd();
    }
    public static void main(String[] args) throws Exception {
        AtomicInteger calls = new AtomicInteger();
        TransformManager manager = new TransformManager(ManagerTest.class.getClassLoader(), (targets, loader) -> calls.incrementAndGet());
        DefaultTransformers.register(manager);
        require(manager.transform("net.minecraft.client.Minecraft", new byte[0]) == null, "inactive");
        manager.init(); manager.init();
        require(calls.get() == 1, "idempotent init");
        String[] targets = manager.getTargets();
        require(targets.length == 3, "targets");
        require(manager.transform("negative.Unrelated", new byte[0]) == null, "negative control");
        for (boolean srg : new boolean[]{false, true}) {
            for (int kind = 0; kind < 3; kind++) {
                byte[] baseline = fixture(targets[kind], kind, srg);
                byte[] changed = manager.transform(targets[kind], baseline);
                require(changed != null && !Arrays.equals(baseline, changed), "changed bytes");
                ClassNode before = new ClassNode(), after = new ClassNode();
                new ClassReader(baseline).accept(before, 0);
                new ClassReader(changed).accept(after, 0);
                require(before.methods.size() == after.methods.size() && before.fields.size() == after.fields.size(), "schema preserved");

                new ClassLoader(ManagerTest.class.getClassLoader()) {
                    Class<?> verify() { return defineClass(null, changed, 0, changed.length); }
                }.verify().getDeclaredMethods();
                require(Arrays.equals(changed, manager.transform(targets[kind], baseline)), "deterministic retransformation");
            }
        }
        try { manager.addBytecodeTransformer("a.B", (n, b, f) -> null); throw new AssertionError("registration not frozen"); }
        catch (IllegalStateException expected) {}
        manager.shutdown(); manager.shutdown();
        require(calls.get() == 2 && !manager.isActive(), "rollback idempotent");
        require(manager.transform(targets[0], new byte[0]) == null, "rollback behavior");
        manager.init(); require(calls.get() == 3, "resume");
        AtomicInteger attempts = new AtomicInteger();
        TransformManager failed = new TransformManager(ManagerTest.class.getClassLoader(), (t, l) -> {
            if (attempts.incrementAndGet() == 1) throw new IllegalStateException("simulated failure");
        });
        failed.addBytecodeTransformer("sample.Target", (n, b, f) -> b);
        try { failed.init(); throw new AssertionError("failed init accepted"); } catch (IllegalStateException expected) {}
        require(!failed.isActive() && attempts.get() == 2, "failure rollback");
        System.out.println("PASS manager: MCP/SRG hooks, verifier, schema, negative control, lifecycle, failure rollback");
    }
}
