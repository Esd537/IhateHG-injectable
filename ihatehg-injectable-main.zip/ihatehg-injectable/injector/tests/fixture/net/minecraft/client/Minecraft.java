package net.minecraft.client;
public class Minecraft {
    public static Minecraft getMinecraft() { return new Minecraft(); }
    public void runTick() { dispatchKeypresses(); }
    public void dispatchKeypresses() {}
}
