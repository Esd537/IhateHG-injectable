package net.minecraft.client.renderer;
public class EntityRenderer {
    public void updateCameraAndRender(float ticks, long nanoTime) {}
}
