package net.minecraft.client.entity;
public class EntityPlayerSP {
    public int sent;
    public void onUpdate() {}
    public void sendChatMessage(String message) { sent++; }
}
