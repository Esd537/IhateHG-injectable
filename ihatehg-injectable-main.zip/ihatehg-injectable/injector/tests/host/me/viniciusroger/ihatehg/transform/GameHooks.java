package me.viniciusroger.ihatehg.transform;

public final class GameHooks {
    public static int initialization, tick, key, update, render, chat;
    public static void reset() { initialization = tick = key = update = render = chat = 0; }
    public static void initialize() { initialization++; }
    public static void postTick() { tick++; }
    public static void keyPress() { key++; }
    public static void preUpdate() { update++; }
    public static void renderTick() { render++; }
    public static boolean cancelChat(String message) { chat++; return message.equals("cancel"); }
}
