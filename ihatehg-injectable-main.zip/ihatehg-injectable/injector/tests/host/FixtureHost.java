import java.net.URL;
import java.net.URLClassLoader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.lang.management.ManagementFactory;
import me.viniciusroger.ihatehg.transform.GameHooks;

public final class FixtureHost {
    public static final class LaunchClassLoader extends URLClassLoader {
        public LaunchClassLoader(URL url) { super(new URL[]{url}, FixtureHost.class.getClassLoader()); }
        @Override public void addURL(URL url) { super.addURL(url); }
        public void addTransformerExclusion(String prefix) {}
    }
    public static final class PlainLoader extends URLClassLoader {
        public PlainLoader(URL url) { super(new URL[]{url}, FixtureHost.class.getClassLoader()); }
    }
    public static final class NonUrlLoader extends ClassLoader {
        private final java.util.jar.JarFile jar;
        public NonUrlLoader(File path) throws java.io.IOException { super(FixtureHost.class.getClassLoader()); jar = new java.util.jar.JarFile(path); }
        @Override protected Class<?> findClass(String name) throws ClassNotFoundException {
            java.util.jar.JarEntry entry = jar.getJarEntry(name.replace('.', '/') + ".class");
            if (entry == null) throw new ClassNotFoundException(name);
            try (java.io.InputStream stream = jar.getInputStream(entry)) {
                java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                for (int count; (count = stream.read(buffer)) != -1;) bytes.write(buffer, 0, count);
                byte[] data = bytes.toByteArray();
                return defineClass(name, data, 0, data.length);
            } catch (java.io.IOException failure) { throw new ClassNotFoundException(name, failure); }
        }
    }
    public static void main(String[] args) throws Exception {
        String mode = args.length > 1 ? args[1] : "launch";
        ClassLoader loader = mode.equals("nonurl") ? new NonUrlLoader(new File(args[0])) :
                mode.equals("url") ? new PlainLoader(new File(args[0]).toURI().toURL()) :
                new LaunchClassLoader(new File(args[0]).toURI().toURL());
        Class<?> mc = loader.loadClass("net.minecraft.client.Minecraft");
        Class<?> player = loader.loadClass("net.minecraft.client.entity.EntityPlayerSP");
        Class<?> renderer = loader.loadClass("net.minecraft.client.renderer.EntityRenderer");
        Object m = mc.newInstance(), p = player.newInstance(), r = renderer.newInstance();
        System.out.println("READY " + ManagementFactory.getRuntimeMXBean().getName().split("@")[0]);
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        for (String command; (command = input.readLine()) != null && !command.equals("exit");) {
            if (command.equals("constructor")) {
                Class<?> type = loader.loadClass("me.viniciusroger.ihatehg.command.Command");
                Object instance = type.getConstructor(String.class, String[].class).newInstance("probe", new String[0]);
                java.lang.reflect.Field field = type.getDeclaredField("mc");
                field.setAccessible(true);
                if (field.get(instance) == null) throw new AssertionError("Minecraft getter did not link");
                System.out.println("PASS constructor Minecraft getter linked");
                continue;
            }
            GameHooks.reset();
            player.getField("sent").setInt(p, 0);
            mc.getMethod("runTick").invoke(m);
            player.getMethod("onUpdate").invoke(p);
            player.getMethod("sendChatMessage", String.class).invoke(p, "hello");
            player.getMethod("sendChatMessage", String.class).invoke(p, "cancel");
            renderer.getMethod("updateCameraAndRender", float.class, long.class).invoke(r, 0.5f, 1L);
            boolean modified = command.equals("modified");
            int sent = player.getField("sent").getInt(p);
            if (sent != (modified ? 1 : 2) || GameHooks.tick != (modified ? 1 : 0) ||
                    GameHooks.initialization != (modified ? 1 : 0) || GameHooks.key != (modified ? 1 : 0) ||
                    GameHooks.update != (modified ? 1 : 0) || GameHooks.render != (modified ? 1 : 0) ||
                    GameHooks.chat != (modified ? 2 : 0)) throw new AssertionError("Unexpected hooks: " + command);
            if (mc.getDeclaredMethods().length != 3 || mc.getDeclaredFields().length != 0 ||
                    player.getDeclaredMethods().length != 2 || player.getDeclaredFields().length != 1)
                throw new AssertionError("Class schema changed");
            System.out.println("PASS " + command + " sent=" + sent + " tick=" + GameHooks.tick + " schema=unchanged");
        }
        if (loader instanceof URLClassLoader) ((URLClassLoader) loader).close();
    }
}
