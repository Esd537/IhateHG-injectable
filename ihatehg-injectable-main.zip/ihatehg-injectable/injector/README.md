# Native injector

See the [project README](../README.md) for usage, build instructions, architecture, and troubleshooting.

The only required distribution file is `loader.exe`. Its DLL and both Java payloads are embedded. Build outputs, caches, logs, and local reports are excluded from source distribution.
