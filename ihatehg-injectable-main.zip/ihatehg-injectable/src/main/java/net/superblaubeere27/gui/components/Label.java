

package net.superblaubeere27.gui.components;

import net.superblaubeere27.gui.AbstractComponent;
import net.superblaubeere27.gui.IRenderer;
import net.superblaubeere27.gui.Window;

public class Label extends AbstractComponent {
	private String text;

	public Label(IRenderer renderer, String text) {
		super(renderer);
		setText(text);
	}

	@Override
	public void render() {

		renderer.drawString(x, y, text, Window.FOREGROUND);

	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		setWidth(renderer.getStringWidth(text));
		setHeight(renderer.getStringHeight(text));

		this.text = text;
	}
}
