

package net.superblaubeere27.gui.layout;

import net.superblaubeere27.gui.AbstractComponent;

import java.util.List;

public interface ILayoutManager {
	int[] getOptimalDiemension(List<AbstractComponent> components, int maxWidth);

	Layout buildLayout(List<AbstractComponent> components, int width, int height);
}
