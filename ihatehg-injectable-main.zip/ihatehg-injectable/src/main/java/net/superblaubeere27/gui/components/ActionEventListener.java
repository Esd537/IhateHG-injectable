

package net.superblaubeere27.gui.components;

public interface ActionEventListener {

	void onActionEvent();

}
