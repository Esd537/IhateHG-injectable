

package net.superblaubeere27.gui.components;

public interface ValueChangeListener<T> {

	boolean onValueChange(T newValue);

}
