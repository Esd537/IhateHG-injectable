package me.viniciusroger.ihatehg.event;

public class CancellableEvent implements IEvent {
	private boolean cancelled = false;

	public boolean isCancelled() {
		return cancelled;
	}

	public void setCancelled(boolean cancelled) {
		this.cancelled = cancelled;
	}
}
