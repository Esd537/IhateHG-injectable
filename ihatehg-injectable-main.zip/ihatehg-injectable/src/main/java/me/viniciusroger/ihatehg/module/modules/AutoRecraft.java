package me.viniciusroger.ihatehg.module.modules;

import io.github.nevalackin.homoBus.Listener;
import io.github.nevalackin.homoBus.annotations.EventLink;
import me.viniciusroger.ihatehg.event.events.RenderTickEvent;
import me.viniciusroger.ihatehg.module.Module;
import me.viniciusroger.ihatehg.setting.settings.BooleanSetting;
import me.viniciusroger.ihatehg.setting.settings.KeybindSetting;
import me.viniciusroger.ihatehg.setting.settings.ListSetting;
import me.viniciusroger.ihatehg.setting.settings.NumberSetting;
import me.viniciusroger.ihatehg.util.misc.TimerHelper;
import me.viniciusroger.ihatehg.util.player.InventoryUtil;
import net.minecraft.block.Block;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemDye;
import net.minecraft.item.ItemStack;
import org.apache.commons.lang3.RandomUtils;
import org.lwjgl.input.Keyboard;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AutoRecraft extends Module {
	private final ListSetting mode = new ListSetting("Mode", 0, new String[]{"Legit", "Blatant"});
	private final ListSetting type = new ListSetting("Type", 0, new String[]{"Automatic", "Manual", "Both"});
	private final ListSetting sortMode = new ListSetting("Sort By", 0, new String[]{"Size", "Index"});
	private final KeybindSetting manualBind = new KeybindSetting("Manual Bind", Keyboard.KEY_NONE);
	private final NumberSetting<Integer> startMinDelay = new NumberSetting<>("Start Min Delay", 30, 0, 400, 1);
	private final NumberSetting<Integer> startMaxDelay = new NumberSetting<>("Start Max Delay", 40, 0, 400, 1);
	private final NumberSetting<Integer> recraftMinDelay = new NumberSetting<>("Recraft Min Delay", 30, 0, 400, 1);
	private final NumberSetting<Integer> recraftMaxDelay = new NumberSetting<>("Recraft Max Delay", 40, 0, 400, 1);
	private final NumberSetting<Integer> startWith = new NumberSetting<>("Start With", 0, 0, 35, 1);
	private final BooleanSetting cocoaMode = new BooleanSetting("Cocoa", true);
	private final BooleanSetting cactusMode = new BooleanSetting("Cactus", false);
	private final BooleanSetting mushroomMode = new BooleanSetting("Mushroom", true);
	private final BooleanSetting onlyInInventory = new BooleanSetting("Only In Inventory", true);
	private final BooleanSetting autoOpenInventory = new BooleanSetting("Auto Open Inventory", false);
	private final BooleanSetting autoCloseInventory = new BooleanSetting("Auto Close Inventory", false);
	private final BooleanSetting spoofInventory = new BooleanSetting("Spoof Inventory", false);

	private final TimerHelper startTimer = new TimerHelper();
	private final TimerHelper recraftTimer = new TimerHelper();

	private final HashMap<String, Integer> recraftMap = new HashMap<>();

	private boolean keyPressed = false;
	public boolean start = false;

	private long startDelay = 0;
	private long recraftDelay = 0;
	private int step = 1;
	private boolean inventorySpoofed = false;

	public AutoRecraft() {
		super("AutoRecraft", Keyboard.KEY_NONE);
	}

	@Override
	protected void onEnable() {
		startDelay = RandomUtils.nextLong(
				Math.min(startMinDelay.getValue(), startMaxDelay.getValue()),
				Math.max(startMinDelay.getValue(), startMaxDelay.getValue())
		);
	}

	@Override
	protected void onDisable() {
		reset();
	}

	@EventLink
	private final Listener<RenderTickEvent> onRenderTick = (event) -> {
		if (mc.theWorld == null || mc.thePlayer == null) {
			reset();

			return;
		}

		if (start) {
			if (onlyInInventory.getValue()) {
				if (!spoofInventory.getValue()) {
					if (mc.currentScreen == null || !(mc.currentScreen instanceof GuiInventory)) {
						reset();

						return;
					}
				} else {
					if (!inventorySpoofed) {
						reset();

						return;
					}
				}
			}

			if (!recraftMap.isEmpty()) {
				if (mode.getValue().equals("Blatant")) {
					int offset = 1;

					for (Map.Entry<String, Integer> entry : recraftMap.entrySet()) {
						mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, entry.getValue(), 1, 0, mc.thePlayer);
						mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, offset, 0, 0, mc.thePlayer);

						offset++;
					}

					mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 0, 0, 1, mc.thePlayer);

					for (Map.Entry<String, Integer> ignored : recraftMap.entrySet()) {
						mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, offset, 0, 1, mc.thePlayer);

						offset--;
					}

					if (autoCloseInventory.getValue()) {
						if (inventorySpoofed) {
							if (mc.currentScreen == null) {
								InventoryUtil.closeInventoryPacket();

								inventorySpoofed = false;
							} else if (mc.currentScreen instanceof GuiInventory) {
								InventoryUtil.closeInventory();
							}
						} else if (mc.currentScreen instanceof GuiInventory) {
							InventoryUtil.closeInventory();
						}
					}

					reset();
				} else {
					if (recraftTimer.hasTimeReached(recraftDelay, true)) {
						recraftDelay = RandomUtils.nextLong(Math.min(recraftMinDelay.getValue(), recraftMaxDelay.getValue()), Math.max(recraftMinDelay.getValue(), recraftMaxDelay.getValue()));

						if (recraftMap.size() == 2) { 
							switch (step) {
								case 1:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, recraftMap.get("bowl"), 1, 0, mc.thePlayer);

									step++;

									break;
								case 2:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 1, 0, 0, mc.thePlayer);

									step++;

									break;
								case 3:
									if (cactusMode.getValue() && recraftMap.containsKey("cactus")) {
										mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, recraftMap.get("cactus"), 1, 0, mc.thePlayer);
									} else if (cocoaMode.getValue() && recraftMap.containsKey("cocoa")) {
										mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, recraftMap.get("cocoa"), 1, 0, mc.thePlayer);
									}

									step++;

									break;
								case 4:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 2, 0, 0, mc.thePlayer);

									step++;

									break;
								case 5:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 0, 0, 1, mc.thePlayer);

									step++;

									break;
								case 6:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 2, 0, 1, mc.thePlayer);

									step++;

									break;
								case 7:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 1, 0, 1, mc.thePlayer);

									step++;

									break;
								case 8:
									if (autoCloseInventory.getValue()) {
										if (inventorySpoofed) {
											if (mc.currentScreen == null) {
												InventoryUtil.closeInventoryPacket();

												inventorySpoofed = false;
											} else if (mc.currentScreen instanceof GuiInventory) {
												InventoryUtil.closeInventory();
											}
										} else if (mc.currentScreen instanceof GuiInventory) {
											InventoryUtil.closeInventory();
										}
									}

									reset();

									break;
							}
						} else if (recraftMap.size() == 3) { 
							switch (step) {
								case 1:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, recraftMap.get("bowl"), 1, 0, mc.thePlayer);

									step++;

									break;
								case 2:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 1, 0, 0, mc.thePlayer);

									step++;

									break;
								case 3:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, recraftMap.get("red"), 1, 0, mc.thePlayer);

									step++;

									break;
								case 4:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 2, 0, 0, mc.thePlayer);

									step++;

									break;
								case 5:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, recraftMap.get("brown"), 1, 0, mc.thePlayer);

									step++;

									break;
								case 6:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 3, 0, 0, mc.thePlayer);

									step++;

									break;
								case 7:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 0, 0, 1, mc.thePlayer);

									step++;

									break;
								case 8:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 3, 0, 1, mc.thePlayer);

									step++;

									break;
								case 9:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 2, 0, 1, mc.thePlayer);

									step++;

									break;
								case 10:
									mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 1, 0, 1, mc.thePlayer);

									step++;

									break;
								case 11:
									if (autoCloseInventory.getValue()) {
										if (inventorySpoofed) {
											if (mc.currentScreen == null) {
												InventoryUtil.closeInventoryPacket();

												inventorySpoofed = false;
											} else if (mc.currentScreen instanceof GuiInventory) {
												InventoryUtil.closeInventory();
											}
										} else if (mc.currentScreen instanceof GuiInventory) {
											InventoryUtil.closeInventory();
										}
									}

									reset();

									break;
							}
						}
					}
				}
			} else {
				if (autoCloseInventory.getValue()) {
					if (inventorySpoofed) {
						if (mc.currentScreen == null) {
							InventoryUtil.closeInventoryPacket();

							inventorySpoofed = false;
						} else if (mc.currentScreen instanceof GuiInventory) {
							InventoryUtil.closeInventory();
						}
					} else if (mc.currentScreen instanceof GuiInventory) {
						InventoryUtil.closeInventory();
					}
				}

				reset();
			}
		} else {
			switch (type.getValue()) {
				case "Automatic":
					if (InventoryUtil.getSoupAmount(9, 45) > startWith.getValue()) {
						return;
					}

					break;
				case "Manual":
					if (keyPressed) {
						break;
					}

					if (Keyboard.isKeyDown(manualBind.getValue())) {
						if (!keyPressed) {
							keyPressed = true;
						}
					} else {
						return;
					}

					break;
				case "Both":
					if (keyPressed) {
						break;
					}

					if (Keyboard.isKeyDown(manualBind.getValue())) {
						if (!keyPressed) {
							keyPressed = true;
						}

						break;
					}

					if (InventoryUtil.getSoupAmount(9, 45) > startWith.getValue()) {
						return;
					}

					break;
			}

			if (startTimer.hasTimeReached(startDelay, true)) {
				keyPressed = false;
				start = true;

				startDelay = RandomUtils.nextLong(
						Math.min(startMinDelay.getValue(), startMaxDelay.getValue()),
						Math.max(startMinDelay.getValue(), startMaxDelay.getValue())
				);
				recraftDelay = RandomUtils.nextLong(
						Math.min(recraftMinDelay.getValue(), recraftMaxDelay.getValue()),
						Math.max(recraftMinDelay.getValue(), recraftMaxDelay.getValue())
				);

				getRecraft();

				if (recraftMap.size() > 1) {
					if (autoOpenInventory.getValue()) {
						if (mc.currentScreen == null) {
							if (spoofInventory.getValue()) {
								if (!inventorySpoofed) {
									InventoryUtil.openInventoryPacket();

									inventorySpoofed = true;
								}
							} else {
								InventoryUtil.openInventory();
							}
						}
					}
				}
			}
		}
	};

	private void getRecraft() {
		final HashMap<Integer, String> itemSlotMap = new HashMap<>();

		for (int i = 9; i < 45; i++) {
			ItemStack itemStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();

			if (itemStack != null) {
				if (itemStack.getItem() == Items.bowl) {
					itemSlotMap.put(i, "bowl");
				} else if (itemStack.getItem() instanceof ItemDye) {
					if (EnumDyeColor.byDyeDamage(itemStack.getMetadata()) == EnumDyeColor.BROWN) {
						itemSlotMap.put(i, "cocoa");
					}
				}

				if (itemStack.getItem() instanceof ItemBlock) {
					Block block = ((ItemBlock) itemStack.getItem()).getBlock();

					if (block == Blocks.cactus) {
						itemSlotMap.put(i, "cactus");
					} else if (block == Blocks.red_mushroom) {
						itemSlotMap.put(i, "red");
					} else if (block == Blocks.brown_mushroom) {
						itemSlotMap.put(i, "brown");
					}
				}
			}
		}

		Stream<Map.Entry<Integer, String>> itemSlotStream = itemSlotMap.entrySet().stream();

		if (sortMode.getValue().equals("Size")) {
			itemSlotStream = itemSlotStream.sorted(
					Comparator.comparingInt(entrySet ->
							mc.thePlayer.inventoryContainer.getSlot(entrySet.getKey()).getStack().stackSize
					)
			);
		} else {
			itemSlotStream = itemSlotStream.sorted(
					Comparator.comparingInt(entrySet ->
							mc.thePlayer.inventoryContainer.getSlot(entrySet.getKey()).getStack().stackSize
					)
			).sorted(Map.Entry.comparingByKey((e1, e2) -> e2 - e1));
		}

		for (Map.Entry<Integer, String> entry : itemSlotStream.collect(Collectors.toList())) {
			recraftMap.put(entry.getValue(), entry.getKey());
		}

		if (!recraftMap.containsKey("bowl")) {
			itemSlotMap.clear();
			recraftMap.clear();

			return;
		}

		if (recraftMap.containsKey("red") && !recraftMap.containsKey("brown")) {
			recraftMap.remove("red");
		} else if (recraftMap.containsKey("brown") && !recraftMap.containsKey("red")) {
			recraftMap.remove("brown");
		}

		recraftMap.entrySet().removeIf(entry -> {
			if (!entry.getKey().equals("bowl")) {
				if (cocoaMode.getValue() && recraftMap.containsKey("cocoa")) {
					return !entry.getKey().equals("cocoa");
				}

				if (cactusMode.getValue() && recraftMap.containsKey("cactus")) {
					return !entry.getKey().equals("cactus");
				}

				if (mushroomMode.getValue()) {
					if (recraftMap.containsKey("brown") && recraftMap.containsKey("red")) {
						return !entry.getKey().equals("brown") && !entry.getKey().equals("red");
					}
				}
			}

			return false;
		});

		if (recraftMap.size() <= 1) {
			recraftMap.clear();
		}

		itemSlotMap.clear();
	}

	private void reset() {
		keyPressed = false;
		start = false;

		step = 1;
		inventorySpoofed = false;

		recraftTimer.reset();
		startTimer.reset();

		recraftMap.clear();
	}
}
