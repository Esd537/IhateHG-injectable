package me.viniciusroger.ihatehg.module;

import io.github.nevalackin.homoBus.Listener;
import io.github.nevalackin.homoBus.annotations.EventLink;
import me.viniciusroger.ihatehg.IHateHG;
import me.viniciusroger.ihatehg.clickgui.ClickGUI;
import me.viniciusroger.ihatehg.event.events.KeyPressEvent;
import me.viniciusroger.ihatehg.module.modules.AutoRecraft;
import me.viniciusroger.ihatehg.module.modules.AutoRefill;
import me.viniciusroger.ihatehg.module.modules.AutoSoup;
import me.viniciusroger.ihatehg.module.modules.ClickGUIModule;

import java.util.ArrayList;
import java.util.Arrays;

public class ModuleManager {
	public static final ArrayList<Module> MODULES = new ArrayList<>();

	public static void init() {
		MODULES.addAll(Arrays.asList(
				new ClickGUIModule(),
				new AutoRecraft(),
				new AutoSoup(),
				new AutoRefill()
		));

		MODULES.forEach(Module::registerSettings);

		getModuleByClass(ClickGUIModule.class).clickGUI = new ClickGUI();

		IHateHG.EVENT_BUS.subscribe(new ModuleManager());
	}

	@EventLink
	private final Listener<KeyPressEvent> onKeyPress = (event) -> {
		for (Module module : MODULES) {
			if (event.getKey() == module.getKeybind()) {
				module.toggle();
			}
		}
	};

	@SuppressWarnings("unchecked")
	public static <T extends Module> T getModuleByClass(Class<T> clazz) {
		return (T) MODULES.stream()
				.filter(module -> module.getClass().equals(clazz))
				.findFirst()
				.orElse(null);
	}

	public static Module getModuleByName(String name) {
		return MODULES.stream()
				.filter(module -> module.getName().replace(" ", "").equalsIgnoreCase(name))
				.findFirst()
				.orElse(null);
	}
}
