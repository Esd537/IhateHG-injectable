package me.viniciusroger.ihatehg.event.events;

import me.viniciusroger.ihatehg.event.IEvent;

public class PreUpdateEvent implements IEvent {
}
