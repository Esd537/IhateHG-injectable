package me.viniciusroger.ihatehg.transform;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.jar.JarFile;

final class MappingNames {
    private static final Map<String, String> METHODS = load();

    private MappingNames() {}

    static boolean matches(String actual, String mcp) {
        return actual.equals(mcp) || mcp.equals(METHODS.get(actual));
    }

    private static Map<String, String> load() {
        String resource = "mappings/1.8.9/methods.csv";
        try {
            InputStream input = MappingNames.class.getClassLoader().getResourceAsStream(resource);
            if (input != null) try (InputStream stream = input) { return read(stream); }
            String payload = NativeBootstrap.getPayloadJar();
            if (payload == null) throw new IOException("Mapping table missing");
            try (JarFile jar = new JarFile(payload)) {
                if (jar.getJarEntry(resource) == null) throw new IOException("Mapping table missing in payload");
                try (InputStream stream = jar.getInputStream(jar.getJarEntry(resource))) { return read(stream); }
            }
        } catch (IOException error) { throw new IllegalStateException("Cannot load Minecraft 1.8.9 mappings", error); }
    }

    private static Map<String, String> read(InputStream stream) throws IOException {
        Map<String, String> names = new HashMap<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        for (String line; (line = reader.readLine()) != null;) {
            String[] columns = line.split(",", 3);
            if (columns.length >= 2 && columns[0].startsWith("func_")) names.put(columns[0], columns[1]);
        }
        if (names.isEmpty()) throw new IOException("Empty mapping table");
        return Collections.unmodifiableMap(names);
    }
}
