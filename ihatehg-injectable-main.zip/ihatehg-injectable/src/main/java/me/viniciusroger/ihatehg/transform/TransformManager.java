package me.viniciusroger.ihatehg.transform;

import net.lenni0451.classtransform.transformer.IBytecodeTransformer;
import net.lenni0451.classtransform.utils.tree.BasicClassProvider;
import net.lenni0451.classtransform.utils.FailStrategy;
import java.util.LinkedHashSet;
import java.util.Set;

public final class TransformManager {
    public interface Retransformer { void retransform(String[] targets, ClassLoader loader); }
    private final net.lenni0451.classtransform.TransformerManager delegate;
    private final Set<String> targets = new LinkedHashSet<>();
    private final ClassLoader loader;
    private final Retransformer retransformer;
    private volatile boolean active;
    private boolean frozen;

    public TransformManager(ClassLoader loader, Retransformer retransformer) {
        this(loader, retransformer, null);
    }

    public TransformManager(ClassLoader loader, Retransformer retransformer, final String payloadJar) {
        this.loader = java.util.Objects.requireNonNull(loader, "loader");
        this.retransformer = java.util.Objects.requireNonNull(retransformer, "retransformer");
        delegate = new net.lenni0451.classtransform.TransformerManager(new BasicClassProvider(loader) {
            @Override public byte[] getClass(String name) throws ClassNotFoundException {
                try { return super.getClass(name); }
                catch (ClassNotFoundException missing) {
                    if (payloadJar == null) throw missing;

                    try (java.util.jar.JarFile jar = new java.util.jar.JarFile(payloadJar)) {
                        java.util.jar.JarEntry entry = jar.getJarEntry(name.replace('.', '/') + ".class");
                        if (entry == null) throw missing;
                        try (java.io.InputStream stream = jar.getInputStream(entry)) {
                            java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
                            byte[] buffer = new byte[8192];
                            for (int size; (size = stream.read(buffer)) != -1;) output.write(buffer, 0, size);
                            return output.toByteArray();
                        }
                    } catch (java.io.IOException error) { throw new ClassNotFoundException(name, error); }
                }
            }
        });
        delegate.setFailStrategy(FailStrategy.THROW);
    }

    public synchronized void addBytecodeTransformer(String target, IBytecodeTransformer transformer) {
        checkRegistration();
        checkName(target);
        java.util.Objects.requireNonNull(transformer, "transformer");
        targets.add(target);
        delegate.addBytecodeTransformer((name, bytes, frames) ->
                target.equals(name) ? transformer.transform(name, bytes, frames) : null);
    }

    public synchronized void registerTarget(String name) {
        checkRegistration();
        checkName(name);
        targets.add(name);
    }

    public synchronized void addBytecodeTransformer(IBytecodeTransformer transformer) {
        checkRegistration();
        delegate.addBytecodeTransformer(java.util.Objects.requireNonNull(transformer, "transformer"));
    }

    public synchronized void addTransformer(String transformerClass) {
        checkRegistration();
        checkName(transformerClass);
        delegate.addTransformer(transformerClass);
        targets.addAll(delegate.getTransformedClasses());
    }

    public synchronized void init() {
        if (active) return;
        if (targets.isEmpty()) throw new IllegalStateException("No targets registered");
        frozen = true;
        active = true; 
        try {
            retransformer.retransform(getTargets(), loader);
        } catch (RuntimeException | Error failure) {
            active = false;
            try { retransformer.retransform(getTargets(), loader); }
            catch (RuntimeException | Error rollback) { failure.addSuppressed(rollback); }
            throw failure;
        }
    }

    public byte[] transform(String name, byte[] bytecode) {
        if (!active || !targets.contains(name)) return null;
        return delegate.transform(name, bytecode);
    }

    public synchronized void shutdown() {
        if (!active) return;
        active = false;
        try { retransformer.retransform(getTargets(), loader); }
        catch (RuntimeException | Error failure) { active = true; throw failure; }
    }

    public synchronized String[] getTargets() { return targets.toArray(new String[0]); }
    public boolean isActive() { return active; }
    private void checkRegistration() {
        if (frozen) throw new IllegalStateException("Register transformers before init()");
    }
    private static void checkName(String name) {
        if (name == null || name.isEmpty() || name.indexOf('/') >= 0 || name.indexOf('*') >= 0)
            throw new IllegalArgumentException("Use a dotted, explicit class name");
    }
}
