package me.viniciusroger.ihatehg.event;

public interface IEvent {
}
