package me.viniciusroger.ihatehg.command;

import io.github.nevalackin.homoBus.Listener;
import io.github.nevalackin.homoBus.annotations.EventLink;
import me.viniciusroger.ihatehg.IHateHG;
import me.viniciusroger.ihatehg.command.commands.ConfigCommand;
import me.viniciusroger.ihatehg.command.commands.PrefixCommand;
import me.viniciusroger.ihatehg.command.commands.SetValueCommand;
import me.viniciusroger.ihatehg.event.events.SendMessageEvent;

import java.util.ArrayList;
import java.util.Arrays;

public class CommandManager {
	public static String PREFIX = "-";

	private static final ArrayList<Command> COMMANDS = new ArrayList<>();

	public static void init() {
		COMMANDS.addAll(Arrays.asList(
				new ConfigCommand(),
				new PrefixCommand(),
				new SetValueCommand()
		));

		IHateHG.EVENT_BUS.subscribe(new CommandManager());
	}

	@EventLink
	private final Listener<SendMessageEvent> onSendMessage = (event) -> {
		String message = event.getMessage();

		if (message.startsWith(PREFIX)) {
			event.setCancelled(true);

			String[] split = message.substring(PREFIX.length()).split(" ");
			String name = split[0];
			String[] args = Arrays.copyOfRange(split, 1, split.length);

			COMMANDS.forEach(command -> {
				if (command.getName().equals(name)) {
					command.onCommandExecute(args);
				} else if (command.getAlias() != null) {
					for (String aliasName : command.getAlias()) {
						if (name.equals(aliasName)) {
							command.onCommandExecute(args);

							return;
						}
					}
				}
			});
		}
	};
}
