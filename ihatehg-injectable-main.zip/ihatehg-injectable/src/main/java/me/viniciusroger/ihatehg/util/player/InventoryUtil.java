package me.viniciusroger.ihatehg.util.player;

import me.viniciusroger.ihatehg.util.AbstractUtil;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemSoup;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C16PacketClientStatus;

import java.util.ArrayList;

public class InventoryUtil extends AbstractUtil {
	public static int getFirstSoup(int from, int to) {
		for (int i = from; i < to; i++) {
			Slot slot = mc.thePlayer.inventoryContainer.getSlot(i);
			ItemStack itemStack = slot.getStack();

			if (itemStack != null && itemStack.getItem() instanceof ItemSoup) {
				return i;
			}
		}

		return -1;
	}

	public static ArrayList<Integer> getSoups(int from, int to) {
		ArrayList<Integer> slots = new ArrayList<>();

		for (int i = from; i < to; i++) {
			Slot slot = mc.thePlayer.inventoryContainer.getSlot(i);
			ItemStack itemStack = slot.getStack();

			if (itemStack != null && itemStack.getItem() instanceof ItemSoup) {
				slots.add(i);
			}
		}

		return slots;
	}

	public static int getSoupAmount(int from, int to) {
		int counter = 0;

		for (int i = from; i < to; i++) {
			ItemStack itemStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();

			if (itemStack != null && itemStack.getItem() instanceof ItemSoup) {
				counter++;
			}
		}

		return counter;
	}

	public static boolean isFull(int from, int to) {
		int counter = 0;

		for (int i = from; i < to; i++) {
			ItemStack itemStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();

			if (itemStack != null) {
				counter++;
			}
		}

		return counter >= (Math.abs(from - to));
	}

	public static void dropItem(boolean all) {
		if (!mc.thePlayer.isSpectator()) {
			mc.thePlayer.dropOneItem(all);
		}
	}

	public static void openInventory() {
		if (!mc.playerController.isRidingHorse()) {
			mc.getNetHandler().addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
			mc.displayGuiScreen(new GuiInventory(mc.thePlayer));
		}
	}

	public static void closeInventory() {
		mc.thePlayer.closeScreen();
	}

	public static void openInventoryPacket() {
		if (!mc.playerController.isRidingHorse()) {
			mc.getNetHandler().addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
		}
	}

	public static void closeInventoryPacket() {
		mc.getNetHandler().addToSendQueue(new C0DPacketCloseWindow(mc.thePlayer.openContainer.windowId));
	}
}
