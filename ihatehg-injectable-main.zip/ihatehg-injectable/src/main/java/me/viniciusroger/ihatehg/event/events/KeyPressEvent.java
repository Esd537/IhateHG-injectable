package me.viniciusroger.ihatehg.event.events;

import me.viniciusroger.ihatehg.event.IEvent;

public class KeyPressEvent implements IEvent {
	private final int key;

	public KeyPressEvent(int key) {
		this.key = key;
	}

	public int getKey() {
		return key;
	}
}
