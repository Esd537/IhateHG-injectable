package me.viniciusroger.ihatehg.module.modules;

import io.github.nevalackin.homoBus.Listener;
import io.github.nevalackin.homoBus.annotations.EventLink;
import me.viniciusroger.ihatehg.event.events.RenderTickEvent;
import me.viniciusroger.ihatehg.module.Module;
import me.viniciusroger.ihatehg.module.ModuleManager;
import me.viniciusroger.ihatehg.setting.settings.BooleanSetting;
import me.viniciusroger.ihatehg.setting.settings.KeybindSetting;
import me.viniciusroger.ihatehg.setting.settings.ListSetting;
import me.viniciusroger.ihatehg.setting.settings.NumberSetting;
import me.viniciusroger.ihatehg.util.misc.TimerHelper;
import me.viniciusroger.ihatehg.util.player.InventoryUtil;
import net.minecraft.client.gui.inventory.GuiInventory;
import org.apache.commons.lang3.RandomUtils;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

public class AutoRefill extends Module {
	private final ListSetting type = new ListSetting("Type", 0, new String[]{"Automatic", "Manual", "Both"});
	private final KeybindSetting manualBind = new KeybindSetting("Manual Bind", Keyboard.KEY_NONE);
	private final NumberSetting<Integer> startMinDelay = new NumberSetting<>("Start Min Delay", 30, 0, 400, 1);
	private final NumberSetting<Integer> startMaxDelay = new NumberSetting<>("Start Max Delay", 40, 0, 400, 1);
	private final NumberSetting<Integer> refillMinDelay = new NumberSetting<>("Refill Min delay", 5, 0, 400, 1);
	private final NumberSetting<Integer> refillMaxDelay = new NumberSetting<>("Refill Max delay", 10, 0, 400, 1);
	private final NumberSetting<Integer> startWith = new NumberSetting<>("Start With", 0, 0, 9, 1);
	private final BooleanSetting randomize = new BooleanSetting("Randomize", false);
	private final BooleanSetting onlyInInventory = new BooleanSetting("Only In Inventory", true);
	private final BooleanSetting autoOpenInventory = new BooleanSetting("Auto Open Inventory", false);
	private final BooleanSetting autoCloseInventory = new BooleanSetting("Auto Close Inventory", false);
	private final BooleanSetting spoofInventory = new BooleanSetting("Spoof Inventory", false);

	private final TimerHelper startTimer = new TimerHelper();
	private final TimerHelper refillTimer = new TimerHelper();

	private boolean keyPressed = false;
	private boolean start = false;

	private long startDelay = 0;
	private long refillDelay = 0;
	private boolean inventorySpoofed = false;

	public AutoRefill() {
		super("AutoRefill", Keyboard.KEY_NONE);
	}

	@Override
	protected void onEnable() {
		startDelay = RandomUtils.nextLong(
				Math.min(startMinDelay.getValue(), startMaxDelay.getValue()),
				Math.max(startMinDelay.getValue(), startMaxDelay.getValue())
		);
	}

	@Override
	protected void onDisable() {
		reset();
	}

	@EventLink
	private final Listener<RenderTickEvent> onRenderTick = (event) -> {
		AutoRecraft autoRecraft = ModuleManager.getModuleByClass(AutoRecraft.class);

		if (mc.theWorld == null || mc.thePlayer == null) {
			reset();

			return;
		}

		if (autoRecraft.isEnabled() && autoRecraft.start) {
			reset();

			return;
		}

		if (start) {
			if (onlyInInventory.getValue()) {
				if (!spoofInventory.getValue()) {
					if (mc.currentScreen == null || !(mc.currentScreen instanceof GuiInventory)) {
						reset();

						return;
					}
				} else {
					if (!inventorySpoofed) {
						reset();

						return;
					}
				}
			}

			if (InventoryUtil.isFull(36, 45)) {
				if (autoCloseInventory.getValue()) {
					if (inventorySpoofed) {
						if (mc.currentScreen == null) {
							InventoryUtil.closeInventoryPacket();

							inventorySpoofed = false;
						} else if (mc.currentScreen instanceof GuiInventory) {
							InventoryUtil.closeInventory();
						}
					} else if (mc.currentScreen instanceof GuiInventory) {
						InventoryUtil.closeInventory();
					}
				}

				reset();

				return;
			}

			if (refillTimer.hasTimeReached(refillDelay, true)) {
				int soupSlot;

				refillDelay = RandomUtils.nextLong(
						Math.min(refillMinDelay.getValue(), refillMaxDelay.getValue()),
						Math.max(refillMinDelay.getValue(), refillMaxDelay.getValue())
				);

				if (randomize.getValue()) {
					ArrayList<Integer> soupSlots = InventoryUtil.getSoups(9, 36);

					if (!soupSlots.isEmpty()) {
						soupSlot = soupSlots.get(RandomUtils.nextInt(0, soupSlots.size()));
					} else {
						soupSlot = -1;
					}
				} else {
					soupSlot = InventoryUtil.getFirstSoup(9, 36);
				}

				if (soupSlot == -1) {
					if (autoCloseInventory.getValue()) {
						if (inventorySpoofed) {
							if (!(mc.currentScreen instanceof GuiInventory)) {
								InventoryUtil.closeInventoryPacket();

								inventorySpoofed = false;
							} else {
								InventoryUtil.closeInventory();
							}
						} else if (mc.currentScreen instanceof GuiInventory) {
							InventoryUtil.closeInventory();
						}
					}

					reset();

					return;
				}

				mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, soupSlot, 0, 1, mc.thePlayer);
			}
		} else {
			switch (type.getValue()) {
				case "Automatic":
					if (InventoryUtil.getSoupAmount(36, 45) > startWith.getValue()) {
						return;
					}

					break;
				case "Manual":
					if (keyPressed) {
						break;
					}

					if (Keyboard.isKeyDown(manualBind.getValue())) {
						if (!keyPressed) {
							keyPressed = true;
						}
					} else {
						return;
					}

					break;
				case "Both":
					if (keyPressed) {
						break;
					}

					if (Keyboard.isKeyDown(manualBind.getValue())) {
						if (!keyPressed) {
							keyPressed = true;
						}

						break;
					}

					if (InventoryUtil.getSoupAmount(36, 45) > startWith.getValue()) {
						return;
					}

					break;
			}

			if (startTimer.hasTimeReached(startDelay, true)) {
				int soupSlot = InventoryUtil.getFirstSoup(9, 36);

				if (soupSlot != -1) {
					if (autoOpenInventory.getValue()) {
						if (mc.currentScreen == null) {
							if (spoofInventory.getValue()) {
								if (!inventorySpoofed) {
									InventoryUtil.openInventoryPacket();

									inventorySpoofed = true;
								}
							} else {
								InventoryUtil.openInventory();
							}
						}
					}

					startDelay = RandomUtils.nextLong(
							Math.min(startMinDelay.getValue(), startMaxDelay.getValue()),
							Math.max(startMinDelay.getValue(), startMaxDelay.getValue())
					);
					refillDelay = RandomUtils.nextLong(
							Math.min(startMinDelay.getValue(), startMaxDelay.getValue()),
							Math.max(startMinDelay.getValue(), startMaxDelay.getValue())
					);
					start = true;
					keyPressed = false;
				}
			}
		}
	};

	private void reset() {
		start = false;
		keyPressed = false;

		inventorySpoofed = false;
	}
}
