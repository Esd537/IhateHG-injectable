package me.viniciusroger.ihatehg.transform;

import me.viniciusroger.ihatehg.IHateHG;
import me.viniciusroger.ihatehg.event.events.*;
import org.lwjgl.input.Keyboard;

public final class GameHooks {
    private GameHooks() {}

    public static void initialize() { IHateHG.init(); }
    public static void postTick() { IHateHG.EVENT_BUS.post(new PostTickEvent()); }
    public static void preUpdate() { IHateHG.EVENT_BUS.post(new PreUpdateEvent()); }
    public static void renderTick() { IHateHG.EVENT_BUS.post(new RenderTickEvent()); }
    public static void keyPress() {
        if (Keyboard.getEventKeyState()) IHateHG.EVENT_BUS.post(new KeyPressEvent(
                Keyboard.getEventKey() == 0 ? Keyboard.getEventCharacter() + 256 : Keyboard.getEventKey()));
    }
    public static boolean cancelChat(String message) {
        SendMessageEvent event = new SendMessageEvent(message);
        IHateHG.EVENT_BUS.post(event);
        return event.isCancelled();
    }
}
