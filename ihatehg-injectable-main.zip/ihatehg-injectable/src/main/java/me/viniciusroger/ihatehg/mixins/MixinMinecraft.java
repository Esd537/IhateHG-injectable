package me.viniciusroger.ihatehg.mixins;

import me.viniciusroger.ihatehg.IHateHG;
import me.viniciusroger.ihatehg.event.events.KeyPressEvent;
import me.viniciusroger.ihatehg.event.events.PostTickEvent;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MixinMinecraft {

	@Inject(
			method = "runTick",
			at = @At("TAIL")
	)
	public void runTick_callPostTickEvent(CallbackInfo ci) {
		IHateHG.EVENT_BUS.post(new PostTickEvent());
	}

	@Inject(
			method = "runTick",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/Minecraft;dispatchKeypresses()V"
			)
	)
	public void runTick_callKeyPressEvent(CallbackInfo ci) {
		if (Keyboard.getEventKeyState()) {
			IHateHG.EVENT_BUS.post(new KeyPressEvent(
					Keyboard.getEventKey() == 0 ? Keyboard.getEventCharacter() + 256 : Keyboard.getEventKey()
			));
		}
	}

	@Inject(
			method = "startGame",
			at = @At(
					value = "FIELD",
					target = "Lnet/minecraft/client/Minecraft;ingameGUI:Lnet/minecraft/client/gui/GuiIngame;",
					opcode = Opcodes.PUTFIELD
			)
	)
	public void startGame_init(CallbackInfo ci) {
		IHateHG.init();
	}
}
