package me.viniciusroger.ihatehg.util.player;

import me.viniciusroger.ihatehg.util.AbstractUtil;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

public class ChatUtil extends AbstractUtil {
	public static void addMessage(String message) {
		mc.thePlayer.addChatMessage(new ChatComponentText(String.format("[%sIHateHG%s] %s", EnumChatFormatting.RED, EnumChatFormatting.RESET, message)));
	}
}
