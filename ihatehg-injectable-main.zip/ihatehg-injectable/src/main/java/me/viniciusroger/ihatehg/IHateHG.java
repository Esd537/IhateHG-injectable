package me.viniciusroger.ihatehg;

import io.github.nevalackin.homoBus.bus.impl.EventBus;
import me.viniciusroger.ihatehg.command.CommandManager;
import me.viniciusroger.ihatehg.event.IEvent;
import me.viniciusroger.ihatehg.module.ModuleManager;
import me.viniciusroger.ihatehg.util.misc.ConfigUtil;

public class IHateHG {
	public static final EventBus<IEvent> EVENT_BUS = new EventBus<>();

	private static boolean initialized;

	public static synchronized void init() {
		if (initialized) return;
		CommandManager.init();
		ModuleManager.init();

		ConfigUtil.createFolder();

		if (!ConfigUtil.loadConfig("default")) {
			ConfigUtil.createConfig("default");
		}
		initialized = true;
	}
}
