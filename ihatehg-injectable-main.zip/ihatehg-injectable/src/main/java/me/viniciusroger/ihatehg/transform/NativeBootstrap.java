package me.viniciusroger.ihatehg.transform;

public final class NativeBootstrap {
    private static volatile TransformManager manager;
    private static String payloadJar;
    private NativeBootstrap() {}
    public static String getPayloadJar() { return payloadJar; }

    public static synchronized void configure(String jar) {
        if (manager != null) throw new IllegalStateException("Bootstrap already configured");
        payloadJar = jar;
    }

    public static synchronized void start() {
        if (manager == null) {
            manager = new TransformManager(NativeBootstrap.class.getClassLoader(), NativeBridge::retransform, payloadJar);
            DefaultTransformers.register(manager);
        }
        manager.init();
    }

    public static byte[] transform(String name, byte[] bytecode) {
        TransformManager current = manager;
        return current == null ? null : current.transform(name, bytecode);
    }

    public static synchronized void stop() {
        if (manager != null) manager.shutdown();
    }
}
