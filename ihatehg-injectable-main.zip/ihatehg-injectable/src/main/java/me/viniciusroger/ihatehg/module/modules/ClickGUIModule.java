package me.viniciusroger.ihatehg.module.modules;

import io.github.nevalackin.homoBus.Listener;
import io.github.nevalackin.homoBus.annotations.EventLink;
import me.viniciusroger.ihatehg.clickgui.ClickGUI;
import me.viniciusroger.ihatehg.event.events.PreUpdateEvent;
import me.viniciusroger.ihatehg.module.Module;
import org.lwjgl.input.Keyboard;

public class ClickGUIModule extends Module {
	public ClickGUI clickGUI;

	public ClickGUIModule() {
		super("ClickGUI", Keyboard.KEY_INSERT);
	}

	@EventLink
	private final Listener<PreUpdateEvent> onPreUpdate = (event) -> {
		mc.displayGuiScreen(clickGUI);

		setEnabled(false);
	};
}
