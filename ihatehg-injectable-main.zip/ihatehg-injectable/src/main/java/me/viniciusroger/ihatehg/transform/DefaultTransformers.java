package me.viniciusroger.ihatehg.transform;

import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

public final class DefaultTransformers {
    private static final String HOOKS = "me/viniciusroger/ihatehg/transform/GameHooks";
    private DefaultTransformers() {}

    public static void register(TransformManager manager) {
        manager.addBytecodeTransformer("net.minecraft.client.Minecraft", (name, bytes, frames) -> edit(bytes, 0));
        manager.addBytecodeTransformer("net.minecraft.client.entity.EntityPlayerSP", (name, bytes, frames) -> edit(bytes, 1));
        manager.addBytecodeTransformer("net.minecraft.client.renderer.EntityRenderer", (name, bytes, frames) -> edit(bytes, 2));
    }

    private static byte[] edit(byte[] bytes, int kind) {
        ClassNode node = new ClassNode();
        new ClassReader(bytes).accept(node, ClassReader.EXPAND_FRAMES);
        int found = 0;
        for (MethodNode method : node.methods) {
            if (kind == 0 && matches(method, "runTick", "func_71407_l", "()V")) {
                method.instructions.insert(call("initialize", "()V"));
                beforeReturns(method, "postTick");
                boolean keyHook = false;
                for (AbstractInsnNode instruction : method.instructions.toArray()) {
                    if (instruction instanceof MethodInsnNode) {
                        MethodInsnNode invocation = (MethodInsnNode) instruction;
                        if (invocation.owner.equals(node.name) && invocation.desc.equals("()V") &&
                                MappingNames.matches(invocation.name, "dispatchKeypresses")) {
                            method.instructions.insertBefore(instruction, call("keyPress", "()V"));
                            keyHook = true;
                        }
                    }
                }
                if (!keyHook) throw new IllegalStateException("dispatchKeypresses not found: " + node.name);
                found++;
            } else if (kind == 1 && matches(method, "onUpdate", "func_70071_h_", "()V")) {
                method.instructions.insert(call("preUpdate", "()V"));
                found++;
            } else if (kind == 1 && matches(method, "sendChatMessage", "func_71165_d", "(Ljava/lang/String;)V")) {
                InsnList hook = new InsnList();
                LabelNode proceed = new LabelNode();
                hook.add(new VarInsnNode(Opcodes.ALOAD, 1));
                hook.add(call("cancelChat", "(Ljava/lang/String;)Z"));
                hook.add(new JumpInsnNode(Opcodes.IFEQ, proceed));
                hook.add(new InsnNode(Opcodes.RETURN));
                hook.add(proceed);
                method.instructions.insert(hook);
                found++;
            } else if (kind == 2 && matches(method, "updateCameraAndRender", "func_181560_a", "(FJ)V")) {
                beforeReturns(method, "renderTick");
                found++;
            }
        }
        if (found != (kind == 1 ? 2 : 1)) throw new IllegalStateException("Unexpected Minecraft mappings: " + node.name);
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS) {
            @Override protected ClassLoader getClassLoader() { return DefaultTransformers.class.getClassLoader(); }
        };
        node.accept(writer);
        return writer.toByteArray();
    }

    private static boolean matches(MethodNode method, String mcp, String srg, String descriptor) {
        return MappingNames.matches(method.name, mcp) && method.desc.equals(descriptor);
    }
    private static MethodInsnNode call(String name, String descriptor) {
        return new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, name, descriptor, false);
    }
    private static void beforeReturns(MethodNode method, String hook) {
        for (AbstractInsnNode instruction : method.instructions.toArray())
            if (instruction.getOpcode() == Opcodes.RETURN) method.instructions.insertBefore(instruction, call(hook, "()V"));
    }
}
