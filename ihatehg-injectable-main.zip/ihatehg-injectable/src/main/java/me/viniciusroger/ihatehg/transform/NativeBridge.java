package me.viniciusroger.ihatehg.transform;

final class NativeBridge {
    private NativeBridge() {}
    static native void retransform(String[] targets, ClassLoader loader);
}
