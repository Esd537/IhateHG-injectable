package me.viniciusroger.ihatehg.event.events;

import me.viniciusroger.ihatehg.event.CancellableEvent;

public class SendMessageEvent extends CancellableEvent {
	private final String message;

	public SendMessageEvent(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
