package me.viniciusroger.ihatehg.mixins;

import me.viniciusroger.ihatehg.IHateHG;
import me.viniciusroger.ihatehg.event.events.PreUpdateEvent;
import me.viniciusroger.ihatehg.event.events.SendMessageEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityPlayerSP.class)
public class MixinEntityPlayerSP {
	@Inject(method = "onUpdate", at = @At("HEAD"))
	public void onUpdate(CallbackInfo ci) {
		IHateHG.EVENT_BUS.post(new PreUpdateEvent());
	}

	@Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
	public void onSendChatMessage(String message, CallbackInfo ci) {
		SendMessageEvent event = new SendMessageEvent(message);

		IHateHG.EVENT_BUS.post(event);

		if (event.isCancelled()) {
			ci.cancel();
		}
	}
}
