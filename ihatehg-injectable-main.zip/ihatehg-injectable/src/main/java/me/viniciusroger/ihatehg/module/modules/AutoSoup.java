package me.viniciusroger.ihatehg.module.modules;

import io.github.nevalackin.homoBus.Listener;
import io.github.nevalackin.homoBus.annotations.EventLink;
import me.viniciusroger.ihatehg.event.events.PostTickEvent;
import me.viniciusroger.ihatehg.module.Module;
import me.viniciusroger.ihatehg.setting.settings.BooleanSetting;
import me.viniciusroger.ihatehg.setting.settings.KeybindSetting;
import me.viniciusroger.ihatehg.setting.settings.ListSetting;
import me.viniciusroger.ihatehg.setting.settings.NumberSetting;
import me.viniciusroger.ihatehg.util.misc.TimerHelper;
import me.viniciusroger.ihatehg.util.player.InventoryUtil;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.lwjgl.input.Keyboard;

public class AutoSoup extends Module {
	private final ListSetting mode = new ListSetting("Mode", 0, new String[]{"Legit", "Blatant"});
	private final ListSetting type = new ListSetting("Type", 0, new String[]{"Automatic", "Manual"});
	private final KeybindSetting manualBind = new KeybindSetting("Manual Bind", Keyboard.KEY_NONE);
	private final NumberSetting<Double> health = new NumberSetting<>("Health", 10.0, 0.5, 20.0, 0.5);
	private final NumberSetting<Integer> healDelay = new NumberSetting<>("Heal Delay", 50, 0, 400, 1);
	private final NumberSetting<Integer> dropDelay = new NumberSetting<>("Drop Delay", 50, 0, 400, 1);
	private final NumberSetting<Integer> switchDelay = new NumberSetting<>("Switch Delay", 50, 0, 400, 1);
	private final BooleanSetting dropSoup = new BooleanSetting("Drop Soup", true);
	private final BooleanSetting onlyInGame = new BooleanSetting("Only In Game", true);

	private final TimerHelper healTimer = new TimerHelper();
	private final TimerHelper dropTimer = new TimerHelper();
	private final TimerHelper switchTimer = new TimerHelper();

	private boolean keyPressed = false;
	private boolean start = false;

	private boolean healed = false;
	private boolean switched = false;

	private int soupIndex = -1;
	private int originalIndex = -1;
	private int step = 1;

	public AutoSoup() {
		super("AutoSoup", Keyboard.KEY_NONE);
	}

	@Override
	protected void onDisable() {
		reset();
	}

	@EventLink
	private final Listener<PostTickEvent> onPostTick = (event) -> {
		if (mc.theWorld == null || mc.thePlayer == null) {
			reset();

			return;
		}

		if (onlyInGame.getValue() && mc.currentScreen != null) {
			return;
		}

		if (start) {
			if (mode.getValue().equals("Legit")) {
				if (step >= 2 && step <= 3 && soupIndex != -1) {
					if (mc.thePlayer.inventory.currentItem != soupIndex) {
						mc.thePlayer.inventory.currentItem = soupIndex;
					}
				}

				switch (step) {
					case 1:
						if (switchTimer.hasTimeReached(switchDelay.getValue(), true)) {
							mc.thePlayer.inventory.currentItem = soupIndex;

							step++;
						}

						break;
					case 2:
						if (mc.gameSettings.keyBindUseItem.isKeyDown()) {
							KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);

							step++;

							return;
						}

						if (healTimer.hasTimeReached(healDelay.getValue(), true)) {
							KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);

							KeyBinding.onTick(mc.gameSettings.keyBindUseItem.getKeyCode());
						}

						break;
					case 3:
						if (dropSoup.getValue()) {
							if (dropTimer.hasTimeReached(dropDelay.getValue(), true)) {
								InventoryUtil.dropItem(false);

								step++;
							}
						} else {
							step++;
						}

						break;
					case 4:
						if (switchTimer.hasTimeReached(switchDelay.getValue(), true)) {
							mc.thePlayer.inventory.currentItem = originalIndex;

							step++;
						}

						break;
					case 5:
						reset();

						break;
				}
			} else {
				if (healed) {
					mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(
							C07PacketPlayerDigging.Action.RELEASE_USE_ITEM,
							BlockPos.ORIGIN,
							EnumFacing.DOWN
					));

					if (dropSoup.getValue()) {
						mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(
								C07PacketPlayerDigging.Action.DROP_ITEM,
								BlockPos.ORIGIN,
								EnumFacing.DOWN
						));
					}

					mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));

					reset();

					return;
				}

				if (switched) {
					switched = false;

					ItemStack itemStack = mc.thePlayer.inventoryContainer.getSlot(soupIndex + 36).getStack();

					if (itemStack != null) {
						mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(itemStack));
					}

					healed = true;

					return;
				}

				mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(soupIndex));

				switched = true;
			}
		} else {
			soupIndex = InventoryUtil.getFirstSoup(36, 45);

			switch (type.getValue()) {
				case "Automatic":
					if (mc.thePlayer.getHealth() > health.getValue()) {
						return;
					}

					break;
				case "Manual":
					if (keyPressed) {
						break;
					}

					if (Keyboard.isKeyDown(manualBind.getValue())) {
						if (!keyPressed) {
							keyPressed = true;
						}
					} else {
						return;
					}

					break;
				case "Both":
					if (keyPressed) {
						break;
					}

					if (Keyboard.isKeyDown(manualBind.getValue())) {
						if (!keyPressed) {
							keyPressed = true;
						}

						break;
					}

					if (mc.thePlayer.getHealth() > health.getValue()) {
						return;
					}

					break;
			}

			if (soupIndex != -1) {
				soupIndex -= 36;
				originalIndex = mc.thePlayer.inventory.currentItem;

				start = true;
				keyPressed = false;
			}
		}
	};

	private void reset() {
		keyPressed = false;
		start = false;

		healed = false;
		switched = false;

		originalIndex = -1;
		soupIndex = -1;
		step = 1;
	}
}
