package me.viniciusroger.ihatehg.mixins;

import me.viniciusroger.ihatehg.IHateHG;
import me.viniciusroger.ihatehg.event.events.RenderTickEvent;
import net.minecraft.client.renderer.EntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public class MixinEntityRenderer {

	@Inject(
			method = "updateCameraAndRender",
			at = @At("TAIL")
	)
	public void updateCameraAndRender_callRenderTickEvent(
			float partialTicks,
			long nanoTime,
			CallbackInfo ci
	) {
		IHateHG.EVENT_BUS.post(new RenderTickEvent());
	}
}
